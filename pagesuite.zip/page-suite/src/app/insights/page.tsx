"use client";

import { PageGate } from "@/components/PageGate";
import { InsightsView } from "@/components/InsightsView";
import { PageHeader } from "@/components/ui";

export default function InsightsPage() {
  return (
    <>
      <PageHeader
        title="Insights"
        description="Read-only reporting from the Graph API. Nothing on this screen changes your page."
      />
      <PageGate>{(page) => <InsightsView page={page} />}</PageGate>
    </>
  );
}
