import Link from "next/link";
import { getSession } from "@/lib/session";
import { listPages } from "@/lib/store";

const FEATURES = [
  {
    href: "/insights",
    title: "Insights",
    body: "Follower growth, reach, engagement and per-post performance, plus the hours your audience actually shows up.",
  },
  {
    href: "/scheduler",
    title: "Scheduler",
    body: "Compose and queue posts. Scheduling is handed to Facebook itself, so posts still go out if this app is offline.",
  },
  {
    href: "/moderation",
    title: "Moderation",
    body: "Keyword and regex rules that hide, delete or auto-reply to comments, with a full audit log of every action.",
  },
  {
    href: "/monetization",
    title: "Monetization",
    body: "Check your page against Meta's published eligibility criteria and see exactly which gaps are left.",
  },
];

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; connected?: string }>;
}) {
  const params = await searchParams;
  const accountId = await getSession();
  const pages = accountId ? listPages(accountId) : [];

  return (
    <div className="space-y-8">
      <section>
        <h1 className="text-2xl font-semibold tracking-tight">Page Suite</h1>
        <p className="mt-2 max-w-2xl text-sm text-[var(--color-ink-soft)]">
          Four tools for running a Facebook Page, built entirely on the official Graph
          API: scheduling, insights, comment moderation and a monetization readiness
          check.
        </p>
      </section>

      {params.error && (
        <div className="card border-rose-200 bg-rose-50 p-4 text-sm text-[var(--color-bad)]">
          {decodeURIComponent(params.error)}
        </div>
      )}

      {params.connected && (
        <div className="card border-emerald-200 bg-emerald-50 p-4 text-sm text-[var(--color-good)]">
          Account connected. {pages.length} page{pages.length === 1 ? "" : "s"} available.
        </div>
      )}

      {!accountId ? (
        <div className="card p-8">
          <h2 className="text-base font-semibold">Connect your Facebook account</h2>
          <p className="mt-1 max-w-xl text-sm text-[var(--color-ink-soft)]">
            You will be asked to approve read access to your Page insights and content,
            and management access for posting and comment moderation. No billing, ads
            spend or payout permission is requested.
          </p>
          <a href="/api/auth/login" className="btn btn-primary mt-4">
            Connect Facebook
          </a>
        </div>
      ) : (
        <div className="card p-4">
          <p className="text-sm">
            Connected — <strong>{pages.length}</strong> page
            {pages.length === 1 ? "" : "s"} available.
          </p>
          {pages.length > 0 && (
            <p className="mt-1 text-sm text-[var(--color-ink-soft)]">
              {pages.map((page) => page.name).join(", ")}
            </p>
          )}
        </div>
      )}

      <section className="grid gap-4 sm:grid-cols-2">
        {FEATURES.map((feature) => (
          <Link
            key={feature.href}
            href={feature.href}
            className="card p-5 transition-colors hover:border-[var(--color-brand)]"
          >
            <h2 className="text-base font-semibold">{feature.title}</h2>
            <p className="mt-1 text-sm text-[var(--color-ink-soft)]">{feature.body}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
