"use client";

import { PageGate } from "@/components/PageGate";
import { MonetizationView } from "@/components/MonetizationView";
import { PageHeader } from "@/components/ui";

export default function MonetizationPage() {
  return (
    <>
      <PageHeader
        title="Monetization readiness"
        description="Your page measured against Meta's published eligibility thresholds, with the gaps spelled out."
      />
      <PageGate>{(page) => <MonetizationView page={page} />}</PageGate>
    </>
  );
}
