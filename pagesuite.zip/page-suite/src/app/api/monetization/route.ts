import { graph, graphPaged } from "@/lib/graph";
import { requirePage, ok, handleError, ApiError } from "@/lib/api";
import { fetchPageInsights, sumSeries } from "@/lib/insights";
import { evaluate, CHECKS, THRESHOLDS_REVIEWED, type Signals } from "@/lib/monetization";
import { db, now } from "@/lib/db";

function readAnswers(pageId: string): Record<string, boolean> {
  const rows = db()
    .prepare(`SELECT check_id, answer FROM monetization_answers WHERE page_id = ?`)
    .all(pageId) as Array<{ check_id: string; answer: number }>;

  return Object.fromEntries(rows.map((row) => [row.check_id, row.answer === 1]));
}

/**
 * Collects every measurable signal. Each piece is independently fallible —
 * a page with no video library, or a Graph version that dropped a metric —
 * so failures become `null` ("could not measure") rather than 0 ("you failed").
 * That distinction is the whole point: reporting an unmeasured threshold as a
 * failure would send someone chasing a problem they may not have.
 */
async function collectSignals(pageId: string, token: string): Promise<Signals> {
  const until = Math.floor(Date.now() / 1000);
  const since60 = until - 60 * 86400;
  const since30 = until - 30 * 86400;

  const [profile, videos, recentPosts, insights] = await Promise.allSettled([
    graph<{ followers_count?: number; fan_count?: number; is_published?: boolean }>(pageId, {
      params: { fields: "followers_count,fan_count,is_published" },
      accessToken: token,
    }),
    graph<{ summary?: { total_count: number } }>(`${pageId}/videos`, {
      params: { limit: 1, summary: "total_count", fields: "id" },
      accessToken: token,
    }),
    graphPaged<{ id: string; created_time: string }>(`${pageId}/posts`, {
      params: { fields: "id,created_time", since: since30, limit: 100 },
      accessToken: token,
      maxPages: 2,
    }),
    fetchPageInsights({
      pageId,
      token,
      metrics: ["page_post_engagements", "page_video_view_time"],
      since: since60,
      until,
    }),
  ]);

  const profileValue = profile.status === "fulfilled" ? profile.value : null;

  let watchMinutes: number | null = null;
  let engagements: number | null = null;

  if (insights.status === "fulfilled") {
    const byMetric = new Map(insights.value.series.map((entry) => [entry.metric, entry]));

    const engagementSeries = byMetric.get("page_post_engagements");
    if (engagementSeries) engagements = sumSeries(engagementSeries);

    // page_video_view_time is reported in milliseconds.
    const watchSeries = byMetric.get("page_video_view_time");
    if (watchSeries) watchMinutes = sumSeries(watchSeries) / 1000 / 60;
  }

  return {
    followers: profileValue?.followers_count ?? profileValue?.fan_count ?? null,
    isPublished: profileValue?.is_published ?? null,
    videoCount:
      videos.status === "fulfilled" ? (videos.value.summary?.total_count ?? null) : null,
    postsLast30Days: recentPosts.status === "fulfilled" ? recentPosts.value.length : null,
    watchMinutes60Days: watchMinutes,
    engagements60Days: engagements,
  };
}

export async function GET(request: Request) {
  try {
    const { page, token } = await requirePage(request);

    const signals = await collectSignals(page.id, token);
    const report = evaluate(signals, readAnswers(page.id));

    return ok({
      page: { id: page.id, name: page.name },
      signals,
      thresholdsReviewed: THRESHOLDS_REVIEWED,
      ...report,
    });
  } catch (error) {
    return handleError(error);
  }
}

/** Records an answer to one of the self-reported policy checks. */
export async function POST(request: Request) {
  try {
    const { page } = await requirePage(request);
    const body = (await request.json()) as { checkId?: string; answer?: boolean };

    if (!body.checkId) throw new ApiError(400, "Missing checkId.");
    if (typeof body.answer !== "boolean") throw new ApiError(400, "Missing answer.");

    const check = CHECKS.find((item) => item.id === body.checkId);
    if (!check) throw new ApiError(404, "Unknown check.");
    if (check.kind !== "manual") {
      throw new ApiError(400, "That check is measured automatically and cannot be overridden.");
    }

    db()
      .prepare(
        `INSERT INTO monetization_answers (page_id, check_id, answer, updated_at)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(page_id, check_id) DO UPDATE SET
           answer = excluded.answer,
           updated_at = excluded.updated_at`,
      )
      .run(page.id, body.checkId, body.answer ? 1 : 0, now());

    return ok({ checkId: body.checkId, answer: body.answer });
  } catch (error) {
    return handleError(error);
  }
}
