import { graphPaged } from "@/lib/graph";
import { requirePage, ok, handleError } from "@/lib/api";

/**
 * Per-post performance plus a "best hours" summary.
 *
 * The hour analysis is computed here from the page's own post history rather
 * than requested from Meta — there is no Graph metric for it. That means it is
 * honest but only as good as the sample: with fewer than ~10 posts the ranking
 * is noise, and the response says so via `sampleSize`.
 */

interface RawPost {
  id: string;
  message?: string;
  story?: string;
  created_time: string;
  permalink_url?: string;
  shares?: { count: number };
  comments?: { summary?: { total_count: number } };
  reactions?: { summary?: { total_count: number } };
  insights?: {
    data: Array<{ name: string; values: Array<{ value: unknown }> }>;
  };
}

function metricValue(post: RawPost, name: string): number {
  const entry = post.insights?.data?.find((item) => item.name === name);
  const value = entry?.values?.[0]?.value;
  return typeof value === "number" ? value : 0;
}

export async function GET(request: Request) {
  try {
    const { page, token } = await requirePage(request);

    const requested = Number(new URL(request.url).searchParams.get("limit") ?? 50);
    const limit = Math.min(Math.max(Number.isFinite(requested) ? requested : 50, 5), 100);

    const raw = await graphPaged<RawPost>(`${page.id}/posts`, {
      params: {
        limit: Math.min(limit, 25),
        fields: [
          "id",
          "message",
          "story",
          "created_time",
          "permalink_url",
          "shares",
          "comments.summary(true).limit(0)",
          "reactions.summary(true).limit(0)",
          "insights.metric(post_impressions,post_impressions_unique,post_clicks)",
        ].join(","),
      },
      accessToken: token,
      maxPages: Math.ceil(limit / 25),
    });

    const posts = raw.slice(0, limit).map((post) => {
      const reactions = post.reactions?.summary?.total_count ?? 0;
      const comments = post.comments?.summary?.total_count ?? 0;
      const shares = post.shares?.count ?? 0;
      const reach = metricValue(post, "post_impressions_unique");
      const engagements = reactions + comments + shares;

      return {
        id: post.id,
        message: post.message ?? post.story ?? "",
        createdTime: post.created_time,
        permalink: post.permalink_url ?? null,
        impressions: metricValue(post, "post_impressions"),
        reach,
        clicks: metricValue(post, "post_clicks"),
        reactions,
        comments,
        shares,
        engagements,
        // Guarding against reach 0 keeps brand-new posts from showing Infinity.
        engagementRate: reach > 0 ? engagements / reach : null,
      };
    });

    // Group by local hour of publication to find when this audience responds.
    const buckets = new Map<number, { posts: number; engagements: number; reach: number }>();
    for (const post of posts) {
      const hour = new Date(post.createdTime).getHours();
      const bucket = buckets.get(hour) ?? { posts: 0, engagements: 0, reach: 0 };
      bucket.posts += 1;
      bucket.engagements += post.engagements;
      bucket.reach += post.reach;
      buckets.set(hour, bucket);
    }

    const bestHours = [...buckets.entries()]
      .map(([hour, bucket]) => ({
        hour,
        posts: bucket.posts,
        avgEngagements: bucket.engagements / bucket.posts,
        avgReach: bucket.reach / bucket.posts,
      }))
      .sort((a, b) => b.avgEngagements - a.avgEngagements);

    return ok({
      posts,
      bestHours,
      sampleSize: posts.length,
      // Below this the hour ranking is not worth acting on; the UI says so.
      reliableSample: posts.length >= 10,
    });
  } catch (error) {
    return handleError(error);
  }
}
