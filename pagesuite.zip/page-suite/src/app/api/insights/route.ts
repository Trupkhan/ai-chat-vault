import { graph } from "@/lib/graph";
import { requirePage, ok, handleError } from "@/lib/api";
import {
  PAGE_METRICS,
  fetchPageInsights,
  mergeByDate,
  sumSeries,
} from "@/lib/insights";

const MAX_DAYS = 90; // Graph rejects longer windows on several page metrics.

export async function GET(request: Request) {
  try {
    const { page, token } = await requirePage(request);

    const requested = Number(new URL(request.url).searchParams.get("days") ?? 28);
    const days = Math.min(Math.max(Number.isFinite(requested) ? requested : 28, 7), MAX_DAYS);

    const until = Math.floor(Date.now() / 1000);
    const since = until - days * 86400;

    const [profile, insights] = await Promise.all([
      graph<{
        id: string;
        name: string;
        fan_count?: number;
        followers_count?: number;
        link?: string;
      }>(page.id, {
        params: { fields: "id,name,fan_count,followers_count,link" },
        accessToken: token,
      }),
      fetchPageInsights({
        pageId: page.id,
        token,
        metrics: PAGE_METRICS,
        since,
        until,
      }),
    ]);

    const byMetric = new Map(insights.series.map((entry) => [entry.metric, entry]));
    const adds = sumSeries(byMetric.get("page_fan_adds"));
    const removes = sumSeries(byMetric.get("page_fan_removes"));

    return ok({
      page: {
        id: profile.id,
        name: profile.name,
        followers: profile.followers_count ?? profile.fan_count ?? null,
        link: profile.link ?? null,
      },
      range: { days, since, until },
      totals: {
        impressions: sumSeries(byMetric.get("page_impressions")),
        reach: sumSeries(byMetric.get("page_impressions_unique")),
        engagements: sumSeries(byMetric.get("page_post_engagements")),
        views: sumSeries(byMetric.get("page_views_total")),
        followerAdds: adds,
        followerRemoves: removes,
        netFollowers: adds - removes,
      },
      chart: mergeByDate(insights.series),
      available: insights.series.map((entry) => entry.metric),
      unavailable: insights.unavailable,
    });
  } catch (error) {
    return handleError(error);
  }
}
