import { graph, graphPaged, GraphError } from "@/lib/graph";
import { requirePage, ok, handleError, ApiError } from "@/lib/api";
import { validateScheduleTime, validateContent } from "@/lib/scheduling";

interface RawPost {
  id: string;
  message?: string;
  story?: string;
  created_time?: string;
  scheduled_publish_time?: number;
  permalink_url?: string;
  is_published?: boolean;
  full_picture?: string;
}

const PUBLISHED_FIELDS = "id,message,story,created_time,permalink_url,full_picture";
const SCHEDULED_FIELDS = "id,message,story,created_time,scheduled_publish_time,is_published";

/** Lists published posts and the pending queue side by side. */
export async function GET(request: Request) {
  try {
    const { page, token } = await requirePage(request);

    const [published, scheduled] = await Promise.all([
      graphPaged<RawPost>(`${page.id}/posts`, {
        params: { fields: PUBLISHED_FIELDS, limit: 25 },
        accessToken: token,
        maxPages: 1,
      }),
      fetchScheduled(page.id, token),
    ]);

    return ok({
      published: published.map((post) => ({
        id: post.id,
        message: post.message ?? post.story ?? "",
        createdTime: post.created_time ?? null,
        permalink: post.permalink_url ?? null,
        picture: post.full_picture ?? null,
      })),
      scheduled: scheduled
        .map((post) => ({
          id: post.id,
          message: post.message ?? post.story ?? "",
          scheduledAt: post.scheduled_publish_time ?? null,
        }))
        .sort((a, b) => (a.scheduledAt ?? 0) - (b.scheduledAt ?? 0)),
    });
  } catch (error) {
    return handleError(error);
  }
}

/**
 * The scheduled-post edge has moved between Graph versions. Try the documented
 * one, then fall back, so this keeps working across a version bump instead of
 * showing an empty queue that looks like "nothing scheduled".
 */
async function fetchScheduled(pageId: string, token: string): Promise<RawPost[]> {
  try {
    return await graphPaged<RawPost>(`${pageId}/scheduled_posts`, {
      params: { fields: SCHEDULED_FIELDS, limit: 50 },
      accessToken: token,
      maxPages: 2,
    });
  } catch (error) {
    if (error instanceof GraphError && (error.needsReauth || error.isPermissionError)) {
      throw error;
    }
    return graphPaged<RawPost>(`${pageId}/promotable_posts`, {
      params: { fields: SCHEDULED_FIELDS, is_published: false, limit: 50 },
      accessToken: token,
      maxPages: 2,
    });
  }
}

/** Creates a post — either scheduled or published immediately. */
export async function POST(request: Request) {
  try {
    const { page, token } = await requirePage(request);
    const body = (await request.json()) as {
      message?: string;
      link?: string;
      photoUrl?: string;
      scheduledAt?: number;
      publishNow?: boolean;
    };

    const content = validateContent(body);
    if (!content.ok) throw new ApiError(400, content.error!);

    const publishNow = body.publishNow === true;

    if (!publishNow) {
      if (!body.scheduledAt) {
        throw new ApiError(400, "Pick a date and time, or choose publish now.");
      }
      const timing = validateScheduleTime(body.scheduledAt);
      if (!timing.ok) throw new ApiError(400, timing.error!);
    }

    const scheduleFields = publishNow
      ? { published: true }
      : { published: false, scheduled_publish_time: body.scheduledAt };

    const photoUrl = body.photoUrl?.trim();
    const message = body.message?.trim();
    const link = body.link?.trim();

    const result = photoUrl
      ? await graph<{ id: string; post_id?: string }>(`${page.id}/photos`, {
          method: "POST",
          accessToken: token,
          body: { url: photoUrl, caption: message, ...scheduleFields },
        })
      : await graph<{ id: string }>(`${page.id}/feed`, {
          method: "POST",
          accessToken: token,
          body: { message, link: link || undefined, ...scheduleFields },
        });

    return ok({
      id: "post_id" in result && result.post_id ? result.post_id : result.id,
      published: publishNow,
      scheduledAt: publishNow ? null : body.scheduledAt,
    });
  } catch (error) {
    return handleError(error);
  }
}

/** Cancels a scheduled post, or deletes a published one. */
export async function DELETE(request: Request) {
  try {
    const { token } = await requirePage(request);
    const postId = new URL(request.url).searchParams.get("postId");
    if (!postId) throw new ApiError(400, "Missing postId.");

    await graph<{ success: boolean }>(postId, { method: "DELETE", accessToken: token });
    return ok({ deleted: postId });
  } catch (error) {
    return handleError(error);
  }
}

/** Moves a scheduled post to a new time. */
export async function PATCH(request: Request) {
  try {
    const { token } = await requirePage(request);
    const body = (await request.json()) as { postId?: string; scheduledAt?: number };

    if (!body.postId) throw new ApiError(400, "Missing postId.");
    if (!body.scheduledAt) throw new ApiError(400, "Missing scheduledAt.");

    const timing = validateScheduleTime(body.scheduledAt);
    if (!timing.ok) throw new ApiError(400, timing.error!);

    await graph<{ success: boolean }>(body.postId, {
      method: "POST",
      accessToken: token,
      body: { scheduled_publish_time: body.scheduledAt },
    });

    return ok({ id: body.postId, scheduledAt: body.scheduledAt });
  } catch (error) {
    return handleError(error);
  }
}
