import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import {
  exchangeCodeForToken,
  exchangeForLongLivedToken,
  graph,
  graphPaged,
} from "@/lib/graph";
import { saveAccount, savePages } from "@/lib/store";
import { setSession } from "@/lib/session";
import { safeEqual } from "@/lib/crypto";

interface FbPage {
  id: string;
  name: string;
  category?: string;
  access_token: string;
  tasks?: string[];
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const origin = url.origin;

  const error = url.searchParams.get("error_description") || url.searchParams.get("error");
  if (error) {
    return NextResponse.redirect(`${origin}/?error=${encodeURIComponent(error)}`);
  }

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  if (!code || !state) {
    return NextResponse.redirect(`${origin}/?error=Missing+code+or+state`);
  }

  const store = await cookies();
  const expectedState = store.get("ps_oauth_state")?.value;
  if (!expectedState || !safeEqual(state, expectedState)) {
    return NextResponse.redirect(`${origin}/?error=Invalid+OAuth+state`);
  }
  store.delete("ps_oauth_state");

  try {
    const short = await exchangeCodeForToken(code);
    const long = await exchangeForLongLivedToken(short.access_token);
    const userToken = long.access_token;

    const me = await graph<{ id: string; name: string }>("me", {
      params: { fields: "id,name" },
      accessToken: userToken,
    });

    saveAccount({
      id: me.id,
      name: me.name,
      userToken,
      expiresAt: long.expires_in ? Math.floor(Date.now() / 1000) + long.expires_in : null,
    });

    // Page tokens minted from a long-lived user token do not expire, so this
    // is the moment to capture them for the scheduler and moderation poller.
    const pages = await graphPaged<FbPage>("me/accounts", {
      params: { fields: "id,name,category,access_token,tasks", limit: 100 },
      accessToken: userToken,
      maxPages: 5,
    });

    if (pages.length > 0) savePages(me.id, pages);
    await setSession(me.id);

    return NextResponse.redirect(`${origin}/?connected=1`);
  } catch (cause) {
    const message = cause instanceof Error ? cause.message : "Login failed";
    return NextResponse.redirect(`${origin}/?error=${encodeURIComponent(message)}`);
  }
}
