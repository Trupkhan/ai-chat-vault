import { NextResponse } from "next/server";
import { getSession, clearSession } from "@/lib/session";
import { deleteAccount } from "@/lib/store";

/**
 * Disconnecting removes the stored tokens outright. Cascade deletes take the
 * pages, rules, logs and answers with them — there is no reason to keep a
 * credential the user just asked us to forget.
 */
export async function POST(request: Request) {
  const accountId = await getSession();
  if (accountId) deleteAccount(accountId);
  await clearSession();
  return NextResponse.redirect(new URL("/", request.url), { status: 303 });
}
