import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { cookies } from "next/headers";
import { env, FB_SCOPES } from "@/lib/env";

/** Kicks off Facebook Login. The `state` value is stored in a cookie and
 *  verified on the way back, which is what stops a CSRF-ed callback. */
export async function GET() {
  const state = crypto.randomBytes(16).toString("hex");

  const store = await cookies();
  store.set("ps_oauth_state", state, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 600,
  });

  const url = new URL(`https://www.facebook.com/${env.graphVersion}/dialog/oauth`);
  url.searchParams.set("client_id", env.appId);
  url.searchParams.set("redirect_uri", env.redirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("scope", FB_SCOPES);
  url.searchParams.set("response_type", "code");

  return NextResponse.redirect(url.toString());
}
