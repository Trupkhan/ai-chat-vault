import { requirePage, ok, handleError, ApiError } from "@/lib/api";
import { validateRule, type MatchType, type Action } from "@/lib/moderation";
import {
  listRules,
  createRule,
  deleteRule,
  setRuleEnabled,
} from "@/lib/moderationStore";

export async function GET(request: Request) {
  try {
    const { page } = await requirePage(request);
    return ok({ rules: listRules(page.id) });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: Request) {
  try {
    const { page } = await requirePage(request);
    const body = (await request.json()) as {
      name?: string;
      matchType?: string;
      pattern?: string;
      action?: string;
      replyText?: string;
      priority?: number;
    };

    const validation = validateRule(body);
    if (!validation.ok) throw new ApiError(400, validation.error!);

    const rule = createRule({
      pageId: page.id,
      name: body.name!,
      matchType: body.matchType as MatchType,
      pattern: body.pattern ?? "",
      action: body.action as Action,
      replyText: body.replyText ?? null,
      priority: Number.isFinite(body.priority) ? Number(body.priority) : 100,
    });

    return ok({ rule });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: Request) {
  try {
    const { page } = await requirePage(request);
    const body = (await request.json()) as { id?: number; enabled?: boolean };

    if (typeof body.id !== "number") throw new ApiError(400, "Missing rule id.");
    if (typeof body.enabled !== "boolean") throw new ApiError(400, "Missing enabled flag.");

    setRuleEnabled(page.id, body.id, body.enabled);
    return ok({ rules: listRules(page.id) });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const { page } = await requirePage(request);
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!Number.isFinite(id)) throw new ApiError(400, "Missing rule id.");

    deleteRule(page.id, id);
    return ok({ rules: listRules(page.id) });
  } catch (error) {
    return handleError(error);
  }
}
