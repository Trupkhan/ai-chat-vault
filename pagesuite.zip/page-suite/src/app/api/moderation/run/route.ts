import { NextResponse } from "next/server";
import { requirePage, ok, handleError, ApiError } from "@/lib/api";
import { runModeration } from "@/lib/moderationRunner";
import { getSession } from "@/lib/session";
import { listAllPages, getPageTokenUnscoped } from "@/lib/store";
import { safeEqual } from "@/lib/crypto";
import { env } from "@/lib/env";

/**
 * Two callers, two auth paths:
 *
 *  - A signed-in operator hitting "Run now" (optionally as a dry run).
 *  - An external scheduler with the CRON_SECRET, sweeping every connected page.
 *
 * The cron path never runs dry — it exists to actually apply rules — and it
 * refuses to run at all if CRON_SECRET is unset, so an empty env var can't
 * turn into an open endpoint.
 */
export async function POST(request: Request) {
  const cronHeader = request.headers.get("x-cron-secret");

  if (cronHeader) {
    if (!env.cronSecret) {
      return NextResponse.json(
        { error: "CRON_SECRET is not configured on the server." },
        { status: 503 },
      );
    }
    if (!safeEqual(cronHeader, env.cronSecret)) {
      return NextResponse.json({ error: "Invalid cron secret." }, { status: 401 });
    }
    return runForAllPages();
  }

  try {
    const accountId = await getSession();
    if (!accountId) throw new ApiError(401, "Not signed in.");

    const { page, token } = await requirePage(request);
    const dryRun = new URL(request.url).searchParams.get("dryRun") === "1";

    const summary = await runModeration({ pageId: page.id, token, dryRun });
    return ok(summary);
  } catch (error) {
    return handleError(error);
  }
}

async function runForAllPages(): Promise<NextResponse> {
  const pages = listAllPages();
  const results: Array<Record<string, unknown>> = [];

  for (const page of pages) {
    const token = getPageTokenUnscoped(page.id);
    if (!token) {
      results.push({ pageId: page.id, name: page.name, error: "No stored token." });
      continue;
    }

    try {
      const summary = await runModeration({ pageId: page.id, token });
      results.push({ pageId: page.id, name: page.name, ...summary, outcomes: undefined });
    } catch (cause) {
      results.push({
        pageId: page.id,
        name: page.name,
        error: cause instanceof Error ? cause.message : "Unknown error",
      });
    }
  }

  return NextResponse.json({ pages: results.length, results });
}
