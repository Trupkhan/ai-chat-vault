import { requirePage, ok, handleError } from "@/lib/api";
import { listLog } from "@/lib/moderationStore";

export async function GET(request: Request) {
  try {
    const { page } = await requirePage(request);
    const requested = Number(new URL(request.url).searchParams.get("limit") ?? 100);
    const limit = Math.min(Math.max(Number.isFinite(requested) ? requested : 100, 1), 500);

    return ok({ entries: listLog(page.id, limit) });
  } catch (error) {
    return handleError(error);
  }
}
