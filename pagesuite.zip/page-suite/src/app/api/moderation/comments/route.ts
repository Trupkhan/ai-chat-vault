import { graph } from "@/lib/graph";
import { requirePage, ok, handleError, ApiError } from "@/lib/api";
import { fetchRecentComments } from "@/lib/commentSource";
import { firstMatch } from "@/lib/moderation";
import { listRules, logManualAction } from "@/lib/moderationStore";

/** The inbox: recent comments, annotated with the rule that would match. */
export async function GET(request: Request) {
  try {
    const { page, token } = await requirePage(request);
    const rules = listRules(page.id);
    const comments = await fetchRecentComments({ pageId: page.id, token });

    return ok({
      comments: comments.map((comment) => {
        const rule = firstMatch(rules, comment.message);
        return {
          ...comment,
          matchedRule: rule ? { id: rule.id, name: rule.name, action: rule.action } : null,
        };
      }),
    });
  } catch (error) {
    return handleError(error);
  }
}

/** Manual moderation from the inbox. */
export async function POST(request: Request) {
  try {
    const { page, token } = await requirePage(request);
    const body = (await request.json()) as {
      commentId?: string;
      postId?: string;
      action?: "hide" | "unhide" | "delete" | "reply";
      replyText?: string;
      authorName?: string;
      message?: string;
    };

    if (!body.commentId) throw new ApiError(400, "Missing commentId.");
    if (!body.action) throw new ApiError(400, "Missing action.");
    if (body.action === "reply" && !body.replyText?.trim()) {
      throw new ApiError(400, "Reply text is required.");
    }

    try {
      switch (body.action) {
        case "hide":
          await graph(body.commentId, {
            method: "POST",
            accessToken: token,
            body: { is_hidden: true },
          });
          break;
        case "unhide":
          await graph(body.commentId, {
            method: "POST",
            accessToken: token,
            body: { is_hidden: false },
          });
          break;
        case "delete":
          await graph(body.commentId, { method: "DELETE", accessToken: token });
          break;
        case "reply":
          await graph(`${body.commentId}/comments`, {
            method: "POST",
            accessToken: token,
            body: { message: body.replyText!.trim() },
          });
          break;
      }
    } catch (cause) {
      // Log the failure before rethrowing so the audit trail records attempts,
      // not just successes.
      logManualAction({
        pageId: page.id,
        commentId: body.commentId,
        postId: body.postId ?? null,
        action: body.action,
        authorName: body.authorName ?? null,
        message: body.message ?? null,
        status: "failed",
        detail: cause instanceof Error ? cause.message : "Unknown error",
      });
      throw cause;
    }

    logManualAction({
      pageId: page.id,
      commentId: body.commentId,
      postId: body.postId ?? null,
      action: body.action,
      authorName: body.authorName ?? null,
      message: body.message ?? null,
      status: "applied",
    });

    return ok({ commentId: body.commentId, action: body.action });
  } catch (error) {
    return handleError(error);
  }
}
