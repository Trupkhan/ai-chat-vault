import { getSession } from "@/lib/session";
import { listPages, getUserToken, savePages } from "@/lib/store";
import { graphPaged } from "@/lib/graph";
import { ok, handleError, ApiError } from "@/lib/api";

export async function GET() {
  try {
    const accountId = await getSession();
    if (!accountId) throw new ApiError(401, "Not signed in.");
    return ok({ pages: listPages(accountId) });
  } catch (error) {
    return handleError(error);
  }
}

/** Re-pull the page list — used after the user gains or loses page access. */
export async function POST() {
  try {
    const accountId = await getSession();
    if (!accountId) throw new ApiError(401, "Not signed in.");

    const userToken = getUserToken(accountId);
    if (!userToken) throw new ApiError(401, "No stored token. Reconnect your account.");

    const pages = await graphPaged<{
      id: string;
      name: string;
      category?: string;
      access_token: string;
      tasks?: string[];
    }>("me/accounts", {
      params: { fields: "id,name,category,access_token,tasks", limit: 100 },
      accessToken: userToken,
      maxPages: 5,
    });

    if (pages.length > 0) savePages(accountId, pages);
    return ok({ pages: listPages(accountId), refreshed: pages.length });
  } catch (error) {
    return handleError(error);
  }
}
