"use client";

import { PageGate } from "@/components/PageGate";
import { ModerationView } from "@/components/ModerationView";
import { PageHeader } from "@/components/ui";

export default function ModerationPage() {
  return (
    <>
      <PageHeader
        title="Comment moderation"
        description="Hide, delete or auto-reply to comments by rule. Every action — automatic or manual — is written to an audit log."
      />
      <PageGate>{(page) => <ModerationView page={page} />}</PageGate>
    </>
  );
}
