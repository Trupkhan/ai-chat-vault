"use client";

import { PageGate } from "@/components/PageGate";
import { SchedulerView } from "@/components/SchedulerView";
import { PageHeader } from "@/components/ui";

export default function SchedulerPage() {
  return (
    <>
      <PageHeader
        title="Scheduler"
        description="Compose posts and hand the queue to Facebook. Scheduled posts publish on Meta's side, not ours."
      />
      <PageGate>{(page) => <SchedulerView page={page} />}</PageGate>
    </>
  );
}
