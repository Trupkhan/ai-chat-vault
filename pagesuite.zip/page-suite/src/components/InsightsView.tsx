"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts";
import { apiGet, formatNumber, formatDate } from "@/lib/client";
import { METRIC_LABELS } from "@/lib/metrics";
import { ErrorNote, Spinner, Stat, EmptyState, Chip } from "./ui";
import type { PageSummary } from "./PageGate";

interface InsightsResponse {
  page: { id: string; name: string; followers: number | null; link: string | null };
  range: { days: number };
  totals: {
    impressions: number;
    reach: number;
    engagements: number;
    views: number;
    followerAdds: number;
    followerRemoves: number;
    netFollowers: number;
  };
  chart: Array<Record<string, string | number>>;
  available: string[];
  unavailable: Array<{ metric: string; reason: string }>;
}

interface PostsResponse {
  posts: Array<{
    id: string;
    message: string;
    createdTime: string;
    permalink: string | null;
    impressions: number;
    reach: number;
    clicks: number;
    reactions: number;
    comments: number;
    shares: number;
    engagements: number;
    engagementRate: number | null;
  }>;
  bestHours: Array<{ hour: number; posts: number; avgEngagements: number; avgReach: number }>;
  sampleSize: number;
  reliableSample: boolean;
}

const LINE_COLORS = ["#1d4ed8", "#0891b2", "#7c3aed", "#059669", "#dc2626", "#d97706"];

export function InsightsView({ page }: { page: PageSummary }) {
  const [days, setDays] = useState(28);
  const [overview, setOverview] = useState<InsightsResponse | null>(null);
  const [posts, setPosts] = useState<PostsResponse | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [overviewData, postsData] = await Promise.all([
        apiGet<InsightsResponse>(`/api/insights?pageId=${page.id}&days=${days}`),
        apiGet<PostsResponse>(`/api/insights/posts?pageId=${page.id}&limit=50`),
      ]);
      setOverview(overviewData);
      setPosts(postsData);
    } catch (cause) {
      setError(cause);
    } finally {
      setLoading(false);
    }
  }, [page.id, days]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading && !overview) return <Spinner label="Loading insights…" />;
  if (error) return <ErrorNote error={error} />;
  if (!overview) return null;

  const chartMetrics = overview.available.filter(
    (metric) => metric !== "page_fan_removes",
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        {[7, 28, 90].map((option) => (
          <button
            key={option}
            className={`btn text-xs ${days === option ? "btn-primary" : ""}`}
            onClick={() => setDays(option)}
            disabled={loading}
          >
            {option} days
          </button>
        ))}
        {loading && <span className="text-xs text-[var(--color-ink-soft)]">Refreshing…</span>}
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="Followers"
          value={formatNumber(overview.page.followers)}
          sub={`${overview.totals.netFollowers >= 0 ? "+" : ""}${formatNumber(
            overview.totals.netFollowers,
          )} in ${days}d`}
        />
        <Stat label="Reach" value={formatNumber(overview.totals.reach)} sub={`last ${days} days`} />
        <Stat
          label="Impressions"
          value={formatNumber(overview.totals.impressions)}
          sub={`last ${days} days`}
        />
        <Stat
          label="Engagements"
          value={formatNumber(overview.totals.engagements)}
          sub={`last ${days} days`}
        />
      </div>

      {overview.unavailable.length > 0 && (
        <div className="card border-amber-200 bg-amber-50 p-4 text-sm">
          <p className="font-medium text-[var(--color-warn)]">
            Some metrics were unavailable and are omitted from the charts.
          </p>
          <ul className="mt-2 space-y-1 text-[var(--color-ink-soft)]">
            {overview.unavailable.map((item) => (
              <li key={item.metric}>
                <code className="rounded bg-white px-1">{item.metric}</code> — {item.reason}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-[var(--color-ink-soft)]">
            Meta retires page metrics between Graph versions. Check the metric names against
            the Graph API changelog for {process.env.NEXT_PUBLIC_FB_VERSION ?? "your version"}.
          </p>
        </div>
      )}

      <section className="card p-4">
        <h2 className="mb-4 text-sm font-semibold">Daily trend</h2>
        {overview.chart.length === 0 ? (
          <EmptyState
            title="No insight data for this period."
            hint="New pages and pages with very low activity often return empty series."
          />
        ) : (
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={overview.chart} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
                <CartesianGrid stroke="#eef2f7" vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11, fill: "#64748b" }}
                  tickLine={false}
                  axisLine={{ stroke: "#e2e8f0" }}
                  minTickGap={24}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: "#64748b" }}
                  tickLine={false}
                  axisLine={false}
                  width={48}
                />
                <Tooltip
                  contentStyle={{
                    fontSize: 12,
                    borderRadius: 8,
                    border: "1px solid #e2e8f0",
                  }}
                  formatter={(value: number, name: string) => [
                    formatNumber(value),
                    METRIC_LABELS[name] ?? name,
                  ]}
                />
                <Legend
                  formatter={(value: string) => (
                    <span style={{ fontSize: 12, color: "#475569" }}>
                      {METRIC_LABELS[value] ?? value}
                    </span>
                  )}
                />
                {chartMetrics.map((metric, index) => (
                  <Line
                    key={metric}
                    type="monotone"
                    dataKey={metric}
                    stroke={LINE_COLORS[index % LINE_COLORS.length]}
                    strokeWidth={2}
                    dot={false}
                    connectNulls
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      {posts && posts.bestHours.length > 0 && (
        <section className="card p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold">Best posting hours</h2>
            <Chip tone={posts.reliableSample ? "good" : "warn"}>
              {posts.sampleSize} posts analysed
            </Chip>
          </div>
          {!posts.reliableSample && (
            <p className="mb-3 text-xs text-[var(--color-ink-soft)]">
              Fewer than 10 posts in the sample — treat this ranking as indicative only.
            </p>
          )}
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {posts.bestHours.slice(0, 6).map((slot) => (
              <div
                key={slot.hour}
                className="flex items-center justify-between rounded-lg border border-[var(--color-line)] px-3 py-2"
              >
                <span className="text-sm font-medium tabular-nums">
                  {String(slot.hour).padStart(2, "0")}:00
                </span>
                <span className="text-xs text-[var(--color-ink-soft)]">
                  {slot.avgEngagements.toFixed(1)} avg engagements · {slot.posts} post
                  {slot.posts === 1 ? "" : "s"}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="card overflow-hidden">
        <h2 className="border-b border-[var(--color-line)] px-4 py-3 text-sm font-semibold">
          Post performance
        </h2>
        {!posts || posts.posts.length === 0 ? (
          <EmptyState title="No published posts found." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-[var(--color-line)] text-left text-xs uppercase tracking-wide text-[var(--color-ink-soft)]">
                  <th className="px-4 py-2 font-medium">Post</th>
                  <th className="px-4 py-2 text-right font-medium">Reach</th>
                  <th className="px-4 py-2 text-right font-medium">Reactions</th>
                  <th className="px-4 py-2 text-right font-medium">Comments</th>
                  <th className="px-4 py-2 text-right font-medium">Shares</th>
                  <th className="px-4 py-2 text-right font-medium">Eng. rate</th>
                </tr>
              </thead>
              <tbody>
                {posts.posts.map((post) => (
                  <tr key={post.id} className="border-b border-[var(--color-line)] last:border-0">
                    <td className="max-w-sm px-4 py-2">
                      <p className="truncate">
                        {post.permalink ? (
                          <a
                            href={post.permalink}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[var(--color-brand)] hover:underline"
                          >
                            {post.message || "(no text)"}
                          </a>
                        ) : (
                          post.message || "(no text)"
                        )}
                      </p>
                      <p className="text-xs text-[var(--color-ink-soft)]">
                        {formatDate(post.createdTime)}
                      </p>
                    </td>
                    <td className="px-4 py-2 text-right tabular-nums">
                      {formatNumber(post.reach)}
                    </td>
                    <td className="px-4 py-2 text-right tabular-nums">
                      {formatNumber(post.reactions)}
                    </td>
                    <td className="px-4 py-2 text-right tabular-nums">
                      {formatNumber(post.comments)}
                    </td>
                    <td className="px-4 py-2 text-right tabular-nums">
                      {formatNumber(post.shares)}
                    </td>
                    <td className="px-4 py-2 text-right tabular-nums">
                      {post.engagementRate === null
                        ? "—"
                        : `${(post.engagementRate * 100).toFixed(1)}%`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
