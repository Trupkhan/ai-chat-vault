import Link from "next/link";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/insights", label: "Insights" },
  { href: "/scheduler", label: "Scheduler" },
  { href: "/moderation", label: "Moderation" },
  { href: "/monetization", label: "Monetization" },
];

export function NavBar() {
  return (
    <header className="border-b border-[var(--color-line)] bg-[var(--color-surface)]">
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
        <Link href="/" className="font-semibold tracking-tight">
          Page Suite
        </Link>
        <nav className="flex flex-wrap items-center gap-x-5 gap-y-1 text-sm">
          {LINKS.slice(1).map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-[var(--color-ink-soft)] transition-colors hover:text-[var(--color-brand)]"
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <form action="/api/auth/logout" method="post" className="ml-auto">
          <button type="submit" className="btn text-xs">
            Disconnect
          </button>
        </form>
      </div>
    </header>
  );
}
