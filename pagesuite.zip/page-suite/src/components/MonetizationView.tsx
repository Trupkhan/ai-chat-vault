"use client";

import { useCallback, useEffect, useState } from "react";
import { apiGet, apiSend, formatNumber } from "@/lib/client";
import type { CheckStatus, Product, Signals } from "@/lib/monetization";
import { ErrorNote, Spinner, Chip, Stat } from "./ui";
import type { PageSummary } from "./PageGate";

interface EvaluatedCheck {
  id: string;
  product: Product | null;
  label: string;
  detail: string;
  kind: "auto" | "manual";
  status: CheckStatus;
  actual?: string;
}

interface Report {
  page: { id: string; name: string };
  signals: Signals;
  thresholdsReviewed: string;
  baseline: EvaluatedCheck[];
  products: Array<{
    product: Product;
    label: string;
    checks: EvaluatedCheck[];
    passed: number;
    total: number;
    blocking: EvaluatedCheck[];
    ready: boolean;
  }>;
}

const STATUS_TONE: Record<CheckStatus, "good" | "bad" | "warn" | "neutral"> = {
  pass: "good",
  fail: "bad",
  unknown: "warn",
  manual: "neutral",
};

const STATUS_LABEL: Record<CheckStatus, string> = {
  pass: "Met",
  fail: "Not met",
  unknown: "Can't measure",
  manual: "Needs your confirmation",
};

export function MonetizationView({ page }: { page: PageSummary }) {
  const [report, setReport] = useState<Report | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      setReport(await apiGet<Report>(`/api/monetization?pageId=${page.id}`));
    } catch (cause) {
      setError(cause);
    }
  }, [page.id]);

  useEffect(() => {
    void load();
  }, [load]);

  async function answer(checkId: string, value: boolean) {
    setSaving(checkId);
    try {
      await apiSend(`/api/monetization?pageId=${page.id}`, { checkId, answer: value });
      await load();
    } catch (cause) {
      setError(cause);
    } finally {
      setSaving(null);
    }
  }

  if (error) return <ErrorNote error={error} />;
  if (!report) return <Spinner label="Checking eligibility signals…" />;

  return (
    <div className="space-y-6">
      <div className="card border-amber-200 bg-amber-50 p-4 text-sm">
        <p className="font-medium text-[var(--color-warn)]">This is an estimate, not a decision.</p>
        <p className="mt-1 text-[var(--color-ink-soft)]">
          Meta does not publish a general eligibility API, so this compares your page against
          Meta&rsquo;s <em>published</em> thresholds (reviewed {report.thresholdsReviewed}) using
          the numbers the Graph API exposes. Thresholds change, and policy compliance cannot be
          measured programmatically. Always confirm in Meta Business Suite &rarr; Monetization.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Followers" value={formatNumber(report.signals.followers)} />
        <Stat label="Videos" value={formatNumber(report.signals.videoCount)} />
        <Stat
          label="Watch minutes"
          value={
            report.signals.watchMinutes60Days === null
              ? "—"
              : formatNumber(Math.round(report.signals.watchMinutes60Days))
          }
          sub="last 60 days"
        />
        <Stat
          label="Engagements"
          value={formatNumber(report.signals.engagements60Days)}
          sub="last 60 days"
        />
      </div>

      {report.products.map((product) => (
        <section key={product.product} className="card overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--color-line)] px-4 py-3">
            <h2 className="text-sm font-semibold">{product.label}</h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-[var(--color-ink-soft)]">
                {product.passed}/{product.total} requirements met
              </span>
              <Chip tone={product.ready ? "good" : product.blocking.length > 0 ? "bad" : "warn"}>
                {product.ready
                  ? "Looks ready"
                  : product.blocking.length > 0
                    ? `${product.blocking.length} blocking`
                    : "Unconfirmed"}
              </Chip>
            </div>
          </div>

          <ul className="divide-y divide-[var(--color-line)]">
            {product.checks.map((check) => (
              <CheckRow
                key={check.id}
                check={check}
                saving={saving === check.id}
                onAnswer={answer}
              />
            ))}
          </ul>
        </section>
      ))}

      <section className="card overflow-hidden">
        <h2 className="border-b border-[var(--color-line)] px-4 py-3 text-sm font-semibold">
          Applies to every product
        </h2>
        <ul className="divide-y divide-[var(--color-line)]">
          {report.baseline.map((check) => (
            <CheckRow
              key={check.id}
              check={check}
              saving={saving === check.id}
              onAnswer={answer}
            />
          ))}
        </ul>
      </section>
    </div>
  );
}

function CheckRow({
  check,
  saving,
  onAnswer,
}: {
  check: EvaluatedCheck;
  saving: boolean;
  onAnswer: (checkId: string, value: boolean) => void;
}) {
  return (
    <li className="flex flex-wrap items-start gap-3 px-4 py-3">
      <div className="min-w-0 grow">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium">{check.label}</span>
          <Chip tone={STATUS_TONE[check.status]}>{STATUS_LABEL[check.status]}</Chip>
          {check.actual && (
            <span className="text-xs tabular-nums text-[var(--color-ink-soft)]">
              {check.actual}
            </span>
          )}
        </div>
        <p className="mt-1 text-xs text-[var(--color-ink-soft)]">{check.detail}</p>
      </div>

      {check.kind === "manual" && (
        <div className="flex gap-2">
          <button
            className={`btn text-xs ${check.status === "pass" ? "btn-primary" : ""}`}
            disabled={saving}
            onClick={() => onAnswer(check.id, true)}
          >
            Yes
          </button>
          <button
            className="btn text-xs"
            disabled={saving}
            onClick={() => onAnswer(check.id, false)}
          >
            No
          </button>
        </div>
      )}
    </li>
  );
}
