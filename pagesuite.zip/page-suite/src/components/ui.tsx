"use client";

import type { ReactNode } from "react";
import { ApiClientError } from "@/lib/client";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {description && (
          <p className="mt-1 max-w-2xl text-sm text-[var(--color-ink-soft)]">{description}</p>
        )}
      </div>
      {actions}
    </div>
  );
}

/**
 * Graph API failures are the most common thing that goes wrong in this app, so
 * they get a first-class component that shows Meta's message plus our hint
 * about what to actually do about it.
 */
export function ErrorNote({ error }: { error: unknown }) {
  if (!error) return null;

  const message = error instanceof Error ? error.message : String(error);
  const hint = error instanceof ApiClientError ? error.hint : undefined;
  const needsReauth = error instanceof ApiClientError ? error.needsReauth : false;

  return (
    <div className="card border-rose-200 bg-rose-50 p-4 text-sm">
      <p className="font-medium text-[var(--color-bad)]">{message}</p>
      {hint && <p className="mt-1 text-[var(--color-ink-soft)]">{hint}</p>}
      {needsReauth && (
        <a href="/api/auth/login" className="btn btn-primary mt-3">
          Reconnect Facebook
        </a>
      )}
    </div>
  );
}

export function Spinner({ label = "Loading…" }: { label?: string }) {
  return (
    <p className="py-8 text-center text-sm text-[var(--color-ink-soft)]" role="status">
      {label}
    </p>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="card p-8 text-center">
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="mt-1 text-sm text-[var(--color-ink-soft)]">{hint}</p>}
    </div>
  );
}

export function Stat({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="card p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-[var(--color-ink-soft)]">
        {label}
      </p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
      {sub && <p className="mt-0.5 text-xs text-[var(--color-ink-soft)]">{sub}</p>}
    </div>
  );
}

export function Chip({
  tone = "neutral",
  children,
}: {
  tone?: "neutral" | "good" | "warn" | "bad" | "brand";
  children: ReactNode;
}) {
  const tones: Record<string, string> = {
    neutral: "bg-slate-100 text-slate-700",
    good: "bg-emerald-50 text-emerald-700",
    warn: "bg-amber-50 text-amber-700",
    bad: "bg-rose-50 text-rose-700",
    brand: "bg-[var(--color-brand-soft)] text-[var(--color-brand)]",
  };
  return <span className={`chip ${tones[tone]}`}>{children}</span>;
}
