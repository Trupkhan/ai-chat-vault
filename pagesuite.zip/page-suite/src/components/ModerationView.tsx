"use client";

import { useCallback, useEffect, useState } from "react";
import { apiGet, apiSend, formatDate } from "@/lib/client";
import {
  ACTIONS,
  ACTION_LABELS,
  MATCH_TYPES,
  MATCH_LABELS,
  validateRule,
  type Rule,
  type MatchType,
  type Action,
} from "@/lib/moderation";
import { ErrorNote, Spinner, EmptyState, Chip } from "./ui";
import type { PageSummary } from "./PageGate";

interface Comment {
  id: string;
  postId: string;
  postMessage: string;
  message: string;
  authorName: string | null;
  createdTime: string;
  likeCount: number;
  isHidden: boolean;
  permalink: string | null;
  matchedRule: { id: number; name: string; action: Action } | null;
}

interface LogEntry {
  id: number;
  commentId: string;
  ruleName: string | null;
  action: string;
  authorName: string | null;
  message: string | null;
  status: string;
  detail: string | null;
  createdAt: number;
}

interface RunSummary {
  scanned: number;
  matched: number;
  applied: number;
  failed: number;
  skipped: number;
  dryRun: boolean;
  outcomes: Array<{
    commentId: string;
    ruleName: string;
    action: string;
    status: string;
    message: string;
    detail?: string;
  }>;
}

type Tab = "inbox" | "rules" | "log";

export function ModerationView({ page }: { page: PageSummary }) {
  const [tab, setTab] = useState<Tab>("inbox");
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {(["inbox", "rules", "log"] as Tab[]).map((option) => (
          <button
            key={option}
            className={`btn text-xs capitalize ${tab === option ? "btn-primary" : ""}`}
            onClick={() => {
              setTab(option);
              setError(null);
              setNotice(null);
            }}
          >
            {option}
          </button>
        ))}
      </div>

      {error ? <ErrorNote error={error} /> : null}
      {notice && (
        <div className="card border-emerald-200 bg-emerald-50 p-3 text-sm text-[var(--color-good)]">
          {notice}
        </div>
      )}

      {tab === "inbox" && (
        <InboxTab page={page} onError={setError} onNotice={setNotice} />
      )}
      {tab === "rules" && (
        <RulesTab page={page} onError={setError} onNotice={setNotice} />
      )}
      {tab === "log" && <LogTab page={page} onError={setError} />}
    </div>
  );
}

function InboxTab({
  page,
  onError,
  onNotice,
}: {
  page: PageSummary;
  onError: (error: unknown) => void;
  onNotice: (message: string | null) => void;
}) {
  const [comments, setComments] = useState<Comment[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [replyFor, setReplyFor] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [run, setRun] = useState<RunSummary | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await apiGet<{ comments: Comment[] }>(
        `/api/moderation/comments?pageId=${page.id}`,
      );
      setComments(data.comments);
    } catch (cause) {
      setComments([]);
      onError(cause);
    }
  }, [page.id, onError]);

  useEffect(() => {
    void load();
  }, [load]);

  async function act(comment: Comment, action: string, text?: string) {
    setBusy(comment.id);
    onError(null);
    onNotice(null);
    try {
      await apiSend(`/api/moderation/comments?pageId=${page.id}`, {
        commentId: comment.id,
        postId: comment.postId,
        action,
        replyText: text,
        authorName: comment.authorName,
        message: comment.message,
      });
      onNotice(`Comment ${action === "unhide" ? "unhidden" : `${action}d`}.`);
      setReplyFor(null);
      setReplyText("");
      await load();
    } catch (cause) {
      onError(cause);
    } finally {
      setBusy(null);
    }
  }

  async function runRules(dryRun: boolean) {
    onError(null);
    onNotice(null);
    setRun(null);
    try {
      const summary = await apiSend<RunSummary>(
        `/api/moderation/run?pageId=${page.id}${dryRun ? "&dryRun=1" : ""}`,
        {},
      );
      setRun(summary);
      if (!dryRun) await load();
    } catch (cause) {
      onError(cause);
    }
  }

  return (
    <div className="space-y-4">
      <div className="card flex flex-wrap items-center gap-2 p-3">
        <button className="btn text-xs" onClick={() => runRules(true)}>
          Preview rules (dry run)
        </button>
        <button className="btn btn-primary text-xs" onClick={() => runRules(false)}>
          Run rules now
        </button>
        <span className="text-xs text-[var(--color-ink-soft)]">
          A dry run reports what would happen and changes nothing.
        </span>
      </div>

      {run && (
        <div className="card p-4 text-sm">
          <p className="font-medium">
            {run.dryRun ? "Dry run" : "Run"} complete — scanned {run.scanned}, matched{" "}
            {run.matched}
            {!run.dryRun && `, applied ${run.applied}, skipped ${run.skipped}`}
            {run.failed > 0 && `, failed ${run.failed}`}.
          </p>
          {run.outcomes.length > 0 && (
            <ul className="mt-2 space-y-1 text-xs text-[var(--color-ink-soft)]">
              {run.outcomes.slice(0, 20).map((outcome) => (
                <li key={`${outcome.commentId}-${outcome.ruleName}`}>
                  <strong>{outcome.ruleName}</strong> → {outcome.action} ({outcome.status})
                  {": "}
                  <span className="italic">{outcome.message.slice(0, 80)}</span>
                  {outcome.detail && ` — ${outcome.detail}`}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {!comments ? (
        <Spinner label="Loading comments…" />
      ) : comments.length === 0 ? (
        <EmptyState
          title="No comments on recent posts."
          hint="The inbox reads comments from the 10 most recent posts."
        />
      ) : (
        <ul className="space-y-3">
          {comments.map((comment) => (
            <li key={comment.id} className="card p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">
                  {comment.authorName ?? "Unknown commenter"}
                </span>
                <span className="text-xs text-[var(--color-ink-soft)]">
                  {formatDate(comment.createdTime)}
                </span>
                {comment.isHidden && <Chip tone="warn">Hidden</Chip>}
                {comment.matchedRule && (
                  <Chip tone="brand">
                    matches “{comment.matchedRule.name}” → {comment.matchedRule.action}
                  </Chip>
                )}
              </div>

              <p className="mt-2 text-sm whitespace-pre-wrap">{comment.message || "(no text)"}</p>

              {comment.postMessage && (
                <p className="mt-1 truncate text-xs text-[var(--color-ink-soft)]">
                  on: {comment.postMessage.slice(0, 90)}
                </p>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                {comment.isHidden ? (
                  <button
                    className="btn text-xs"
                    disabled={busy === comment.id}
                    onClick={() => act(comment, "unhide")}
                  >
                    Unhide
                  </button>
                ) : (
                  <button
                    className="btn text-xs"
                    disabled={busy === comment.id}
                    onClick={() => act(comment, "hide")}
                  >
                    Hide
                  </button>
                )}
                <button
                  className="btn text-xs"
                  disabled={busy === comment.id}
                  onClick={() => {
                    setReplyFor(replyFor === comment.id ? null : comment.id);
                    setReplyText("");
                  }}
                >
                  Reply
                </button>
                <button
                  className="btn btn-danger text-xs"
                  disabled={busy === comment.id}
                  onClick={() => {
                    if (window.confirm("Delete this comment permanently?")) {
                      void act(comment, "delete");
                    }
                  }}
                >
                  Delete
                </button>
                {comment.permalink && (
                  <a
                    href={comment.permalink}
                    target="_blank"
                    rel="noreferrer"
                    className="btn text-xs"
                  >
                    Open
                  </a>
                )}
              </div>

              {replyFor === comment.id && (
                <div className="mt-3 flex gap-2">
                  <input
                    className="input"
                    value={replyText}
                    onChange={(event) => setReplyText(event.target.value)}
                    placeholder="Your reply…"
                  />
                  <button
                    className="btn btn-primary text-xs"
                    disabled={!replyText.trim() || busy === comment.id}
                    onClick={() => act(comment, "reply", replyText)}
                  >
                    Send
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function RulesTab({
  page,
  onError,
  onNotice,
}: {
  page: PageSummary;
  onError: (error: unknown) => void;
  onNotice: (message: string | null) => void;
}) {
  const [rules, setRules] = useState<Rule[] | null>(null);
  const [name, setName] = useState("");
  const [matchType, setMatchType] = useState<MatchType>("keyword");
  const [pattern, setPattern] = useState("");
  const [action, setAction] = useState<Action>("hide");
  const [replyText, setReplyText] = useState("");
  const [priority, setPriority] = useState(100);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await apiGet<{ rules: Rule[] }>(
        `/api/moderation/rules?pageId=${page.id}`,
      );
      setRules(data.rules);
    } catch (cause) {
      setRules([]);
      onError(cause);
    }
  }, [page.id, onError]);

  useEffect(() => {
    void load();
  }, [load]);

  async function create(event: React.FormEvent) {
    event.preventDefault();
    onError(null);
    onNotice(null);

    // Same validator the API runs, so the user sees the error without a round trip.
    const validation = validateRule({ name, matchType, pattern, action, replyText });
    if (!validation.ok) {
      onError(new Error(validation.error));
      return;
    }

    setSaving(true);
    try {
      await apiSend(`/api/moderation/rules?pageId=${page.id}`, {
        name,
        matchType,
        pattern,
        action,
        replyText,
        priority,
      });
      onNotice("Rule created.");
      setName("");
      setPattern("");
      setReplyText("");
      await load();
    } catch (cause) {
      onError(cause);
    } finally {
      setSaving(false);
    }
  }

  async function toggle(rule: Rule) {
    try {
      const data = await apiSend<{ rules: Rule[] }>(
        `/api/moderation/rules?pageId=${page.id}`,
        { id: rule.id, enabled: !rule.enabled },
        "PATCH",
      );
      setRules(data.rules);
    } catch (cause) {
      onError(cause);
    }
  }

  async function remove(rule: Rule) {
    if (!window.confirm(`Delete rule “${rule.name}”?`)) return;
    try {
      const data = await apiSend<{ rules: Rule[] }>(
        `/api/moderation/rules?pageId=${page.id}&id=${rule.id}`,
        {},
        "DELETE",
      );
      setRules(data.rules);
      onNotice("Rule deleted.");
    } catch (cause) {
      onError(cause);
    }
  }

  return (
    <div className="space-y-4">
      <form onSubmit={create} className="card space-y-4 p-4">
        <h2 className="text-sm font-semibold">New rule</h2>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="rule-name">
              Name
            </label>
            <input
              id="rule-name"
              className="input"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Block crypto spam"
            />
          </div>
          <div>
            <label className="label" htmlFor="rule-priority">
              Priority (lower runs first)
            </label>
            <input
              id="rule-priority"
              type="number"
              className="input"
              value={priority}
              onChange={(event) => setPriority(Number(event.target.value))}
            />
          </div>
        </div>

        <div>
          <label className="label" htmlFor="rule-match">
            Match type
          </label>
          <select
            id="rule-match"
            className="select"
            value={matchType}
            onChange={(event) => setMatchType(event.target.value as MatchType)}
          >
            {MATCH_TYPES.map((type) => (
              <option key={type} value={type}>
                {MATCH_LABELS[type]}
              </option>
            ))}
          </select>
        </div>

        {matchType !== "link" && (
          <div>
            <label className="label" htmlFor="rule-pattern">
              Pattern
            </label>
            <input
              id="rule-pattern"
              className="input font-mono text-xs"
              value={pattern}
              onChange={(event) => setPattern(event.target.value)}
              placeholder={
                matchType === "keyword" ? "crypto, investment, dm me" : "\\b(free|win)\\b"
              }
            />
          </div>
        )}

        <div>
          <label className="label" htmlFor="rule-action">
            Action
          </label>
          <select
            id="rule-action"
            className="select"
            value={action}
            onChange={(event) => setAction(event.target.value as Action)}
          >
            {ACTIONS.map((option) => (
              <option key={option} value={option}>
                {ACTION_LABELS[option]}
              </option>
            ))}
          </select>
        </div>

        {action === "reply" && (
          <div>
            <label className="label" htmlFor="rule-reply">
              Reply text
            </label>
            <input
              id="rule-reply"
              className="input"
              value={replyText}
              onChange={(event) => setReplyText(event.target.value)}
              placeholder="Thanks for asking — we've sent you a DM."
            />
          </div>
        )}

        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving…" : "Create rule"}
        </button>

        <p className="text-xs text-[var(--color-ink-soft)]">
          Only the first matching rule applies to a comment. Test with a dry run from the
          Inbox tab before enabling anything that deletes.
        </p>
      </form>

      {!rules ? (
        <Spinner />
      ) : rules.length === 0 ? (
        <EmptyState title="No rules yet." hint="Comments are only moderated manually until you add one." />
      ) : (
        <ul className="space-y-2">
          {rules.map((rule) => (
            <li key={rule.id} className="card flex flex-wrap items-center gap-3 p-3">
              <div className="min-w-0 grow">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-medium">{rule.name}</span>
                  <Chip tone={rule.enabled ? "good" : "neutral"}>
                    {rule.enabled ? "Enabled" : "Disabled"}
                  </Chip>
                  <Chip tone={rule.action === "delete" ? "bad" : "brand"}>{rule.action}</Chip>
                  <span className="text-xs text-[var(--color-ink-soft)]">
                    priority {rule.priority}
                  </span>
                </div>
                <p className="mt-1 truncate font-mono text-xs text-[var(--color-ink-soft)]">
                  {rule.matchType}
                  {rule.matchType !== "link" && `: ${rule.pattern}`}
                  {rule.replyText && ` → “${rule.replyText}”`}
                </p>
              </div>
              <button className="btn text-xs" onClick={() => toggle(rule)}>
                {rule.enabled ? "Disable" : "Enable"}
              </button>
              <button className="btn btn-danger text-xs" onClick={() => remove(rule)}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function LogTab({
  page,
  onError,
}: {
  page: PageSummary;
  onError: (error: unknown) => void;
}) {
  const [entries, setEntries] = useState<LogEntry[] | null>(null);

  useEffect(() => {
    apiGet<{ entries: LogEntry[] }>(`/api/moderation/log?pageId=${page.id}`)
      .then((data) => setEntries(data.entries))
      .catch((cause) => {
        setEntries([]);
        onError(cause);
      });
  }, [page.id, onError]);

  if (!entries) return <Spinner />;
  if (entries.length === 0) {
    return <EmptyState title="Nothing logged yet." hint="Every automatic and manual action is recorded here." />;
  }

  return (
    <div className="card overflow-x-auto">
      <table className="w-full min-w-[680px] text-sm">
        <thead>
          <tr className="border-b border-[var(--color-line)] text-left text-xs uppercase tracking-wide text-[var(--color-ink-soft)]">
            <th className="px-4 py-2 font-medium">When</th>
            <th className="px-4 py-2 font-medium">Rule</th>
            <th className="px-4 py-2 font-medium">Action</th>
            <th className="px-4 py-2 font-medium">Author</th>
            <th className="px-4 py-2 font-medium">Comment</th>
            <th className="px-4 py-2 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((entry) => (
            <tr key={entry.id} className="border-b border-[var(--color-line)] last:border-0">
              <td className="whitespace-nowrap px-4 py-2 text-xs">
                {formatDate(entry.createdAt)}
              </td>
              <td className="px-4 py-2 text-xs">{entry.ruleName ?? "—"}</td>
              <td className="px-4 py-2 text-xs">{entry.action}</td>
              <td className="px-4 py-2 text-xs">{entry.authorName ?? "—"}</td>
              <td className="max-w-xs truncate px-4 py-2 text-xs">{entry.message ?? "—"}</td>
              <td className="px-4 py-2">
                <Chip tone={entry.status === "applied" ? "good" : "bad"}>{entry.status}</Chip>
                {entry.detail && (
                  <p className="mt-1 text-xs text-[var(--color-ink-soft)]">{entry.detail}</p>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
