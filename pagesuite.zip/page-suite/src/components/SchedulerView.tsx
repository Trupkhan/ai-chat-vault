"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { apiGet, apiSend, formatDate } from "@/lib/client";
import { MIN_LEAD_SECONDS } from "@/lib/scheduling";
import { ErrorNote, Spinner, EmptyState, Chip } from "./ui";
import type { PageSummary } from "./PageGate";

interface PostsResponse {
  published: Array<{
    id: string;
    message: string;
    createdTime: string | null;
    permalink: string | null;
    picture: string | null;
  }>;
  scheduled: Array<{ id: string; message: string; scheduledAt: number | null }>;
}

/** `datetime-local` value for "now + lead", in the browser's own timezone. */
function defaultSlot(): string {
  const target = new Date(Date.now() + (MIN_LEAD_SECONDS + 900) * 1000);
  const offset = target.getTimezoneOffset() * 60000;
  return new Date(target.getTime() - offset).toISOString().slice(0, 16);
}

export function SchedulerView({ page }: { page: PageSummary }) {
  const [data, setData] = useState<PostsResponse | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [message, setMessage] = useState("");
  const [link, setLink] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [when, setWhen] = useState(defaultSlot);
  const [publishNow, setPublishNow] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      setData(await apiGet<PostsResponse>(`/api/posts?pageId=${page.id}`));
    } catch (cause) {
      setError(cause);
    }
  }, [page.id]);

  useEffect(() => {
    void load();
  }, [load]);

  const scheduledAt = useMemo(
    () => Math.floor(new Date(when).getTime() / 1000),
    [when],
  );

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    setNotice(null);

    try {
      await apiSend(`/api/posts?pageId=${page.id}`, {
        message,
        link: link || undefined,
        photoUrl: photoUrl || undefined,
        scheduledAt: publishNow ? undefined : scheduledAt,
        publishNow,
      });

      setNotice(publishNow ? "Published." : "Scheduled.");
      setMessage("");
      setLink("");
      setPhotoUrl("");
      setWhen(defaultSlot());
      await load();
    } catch (cause) {
      setError(cause);
    } finally {
      setSubmitting(false);
    }
  }

  async function cancelPost(postId: string) {
    if (!window.confirm("Cancel this scheduled post? This cannot be undone.")) return;

    setError(null);
    try {
      await apiSend(`/api/posts?pageId=${page.id}&postId=${postId}`, {}, "DELETE");
      setNotice("Scheduled post cancelled.");
      await load();
    } catch (cause) {
      setError(cause);
    }
  }

  return (
    <div className="space-y-6">
      {error ? <ErrorNote error={error} /> : null}
      {notice && (
        <div className="card border-emerald-200 bg-emerald-50 p-3 text-sm text-[var(--color-good)]">
          {notice}
        </div>
      )}

      <form onSubmit={submit} className="card space-y-4 p-4">
        <div>
          <label className="label" htmlFor="post-message">
            Post text
          </label>
          <textarea
            id="post-message"
            className="textarea min-h-28"
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="What do you want to say?"
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="post-link">
              Link (optional)
            </label>
            <input
              id="post-link"
              className="input"
              value={link}
              onChange={(event) => setLink(event.target.value)}
              placeholder="https://example.com/article"
            />
          </div>
          <div>
            <label className="label" htmlFor="post-photo">
              Image URL (optional)
            </label>
            <input
              id="post-photo"
              className="input"
              value={photoUrl}
              onChange={(event) => setPhotoUrl(event.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>
        </div>

        {photoUrl && link && (
          <p className="text-xs text-[var(--color-warn)]">
            An image URL takes priority — the link will be ignored. Put the URL in the post
            text if you want both.
          </p>
        )}

        <div className="flex flex-wrap items-end gap-4">
          <div className="grow sm:grow-0">
            <label className="label" htmlFor="post-when">
              Publish at
            </label>
            <input
              id="post-when"
              type="datetime-local"
              className="input sm:w-64"
              value={when}
              onChange={(event) => setWhen(event.target.value)}
              disabled={publishNow}
            />
          </div>
          <label className="flex items-center gap-2 pb-2 text-sm">
            <input
              type="checkbox"
              checked={publishNow}
              onChange={(event) => setPublishNow(event.target.checked)}
            />
            Publish immediately
          </label>
          <button type="submit" className="btn btn-primary ml-auto" disabled={submitting}>
            {submitting ? "Working…" : publishNow ? "Publish now" : "Schedule post"}
          </button>
        </div>

        <p className="text-xs text-[var(--color-ink-soft)]">
          Times use your device timezone. Facebook itself holds the queue, so scheduled
          posts publish even when this app is not running. Minimum lead time is 10 minutes.
        </p>
      </form>

      <section className="card overflow-hidden">
        <h2 className="border-b border-[var(--color-line)] px-4 py-3 text-sm font-semibold">
          Scheduled queue
        </h2>
        {!data ? (
          <Spinner />
        ) : data.scheduled.length === 0 ? (
          <EmptyState title="Nothing scheduled." />
        ) : (
          <ul className="divide-y divide-[var(--color-line)]">
            {data.scheduled.map((post) => (
              <li key={post.id} className="flex items-start gap-3 px-4 py-3">
                <div className="min-w-0 grow">
                  <p className="truncate text-sm">{post.message || "(no text)"}</p>
                  <p className="mt-0.5 text-xs text-[var(--color-ink-soft)]">
                    {formatDate(post.scheduledAt)}
                  </p>
                </div>
                <button className="btn btn-danger text-xs" onClick={() => cancelPost(post.id)}>
                  Cancel
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="card overflow-hidden">
        <h2 className="border-b border-[var(--color-line)] px-4 py-3 text-sm font-semibold">
          Recently published
        </h2>
        {!data ? (
          <Spinner />
        ) : data.published.length === 0 ? (
          <EmptyState title="No published posts yet." />
        ) : (
          <ul className="divide-y divide-[var(--color-line)]">
            {data.published.map((post) => (
              <li key={post.id} className="flex items-start gap-3 px-4 py-3">
                <div className="min-w-0 grow">
                  <p className="truncate text-sm">
                    {post.permalink ? (
                      <a
                        href={post.permalink}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[var(--color-brand)] hover:underline"
                      >
                        {post.message || "(no text)"}
                      </a>
                    ) : (
                      post.message || "(no text)"
                    )}
                  </p>
                  <p className="mt-0.5 text-xs text-[var(--color-ink-soft)]">
                    {formatDate(post.createdTime)}
                  </p>
                </div>
                <Chip tone="good">Live</Chip>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
