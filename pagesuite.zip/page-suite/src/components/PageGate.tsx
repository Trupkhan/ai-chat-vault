"use client";

import { useCallback, useEffect, useState, type ReactNode } from "react";
import { apiGet, ApiClientError } from "@/lib/client";
import { ErrorNote, Spinner } from "./ui";

export interface PageSummary {
  id: string;
  name: string;
  category: string | null;
  tasks: string[];
}

const STORAGE_KEY = "page-suite:selected-page";

/**
 * Every feature needs "which page are we acting on?" answered before it can do
 * anything, so that question lives in one place. Children render only once a
 * page is chosen, and the choice persists across tabs and reloads.
 */
export function PageGate({
  children,
}: {
  children: (page: PageSummary) => ReactNode;
}) {
  const [pages, setPages] = useState<PageSummary[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const data = await apiGet<{ pages: PageSummary[] }>("/api/pages");
      setPages(data.pages);

      const stored = window.localStorage.getItem(STORAGE_KEY);
      const valid = stored && data.pages.some((page) => page.id === stored);
      setSelectedId(valid ? stored : (data.pages[0]?.id ?? null));
    } catch (cause) {
      setPages([]);
      setError(cause);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function select(id: string) {
    setSelectedId(id);
    window.localStorage.setItem(STORAGE_KEY, id);
  }

  if (error instanceof ApiClientError && error.status === 401) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm font-medium">Connect your Facebook account to continue.</p>
        <a href="/api/auth/login" className="btn btn-primary mt-4">
          Connect Facebook
        </a>
      </div>
    );
  }

  if (error) return <ErrorNote error={error} />;
  if (pages === null) return <Spinner />;

  if (pages.length === 0) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm font-medium">No Pages found on this account.</p>
        <p className="mt-1 text-sm text-[var(--color-ink-soft)]">
          You need an admin role on at least one Facebook Page, and the app needs the
          <code className="mx-1 rounded bg-slate-100 px-1">pages_show_list</code>
          permission approved.
        </p>
      </div>
    );
  }

  const selected = pages.find((page) => page.id === selectedId);

  return (
    <div className="space-y-6">
      <div className="card flex flex-wrap items-center gap-3 p-3">
        <label htmlFor="page-select" className="text-sm font-medium">
          Page
        </label>
        <select
          id="page-select"
          className="select max-w-xs"
          value={selectedId ?? ""}
          onChange={(event) => select(event.target.value)}
        >
          {pages.map((page) => (
            <option key={page.id} value={page.id}>
              {page.name}
            </option>
          ))}
        </select>
        <span className="text-xs text-[var(--color-ink-soft)]">ID {selected?.id}</span>
      </div>

      {selected ? children(selected) : null}
    </div>
  );
}
