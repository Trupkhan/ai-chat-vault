import { db, now } from "./db";
import type { Rule, MatchType, Action } from "./moderation";

interface RuleRow {
  id: number;
  page_id: string;
  name: string;
  enabled: number;
  match_type: string;
  pattern: string;
  action: string;
  reply_text: string | null;
  priority: number;
}

function toRule(row: RuleRow): Rule {
  return {
    id: row.id,
    pageId: row.page_id,
    name: row.name,
    enabled: row.enabled === 1,
    matchType: row.match_type as MatchType,
    pattern: row.pattern,
    action: row.action as Action,
    replyText: row.reply_text,
    priority: row.priority,
  };
}

export function listRules(pageId: string): Rule[] {
  const rows = db()
    .prepare(`SELECT * FROM moderation_rules WHERE page_id = ? ORDER BY priority, id`)
    .all(pageId) as RuleRow[];
  return rows.map(toRule);
}

export function createRule(input: {
  pageId: string;
  name: string;
  matchType: MatchType;
  pattern: string;
  action: Action;
  replyText?: string | null;
  priority?: number;
}): Rule {
  const result = db()
    .prepare(
      `INSERT INTO moderation_rules
         (page_id, name, enabled, match_type, pattern, action, reply_text, priority, created_at)
       VALUES (@pageId, @name, 1, @matchType, @pattern, @action, @replyText, @priority, @ts)`,
    )
    .run({
      pageId: input.pageId,
      name: input.name.trim(),
      matchType: input.matchType,
      pattern: input.pattern.trim(),
      action: input.action,
      replyText: input.replyText?.trim() || null,
      priority: input.priority ?? 100,
      ts: now(),
    });

  const row = db()
    .prepare(`SELECT * FROM moderation_rules WHERE id = ?`)
    .get(result.lastInsertRowid) as RuleRow;
  return toRule(row);
}

export function setRuleEnabled(pageId: string, ruleId: number, enabled: boolean): void {
  db()
    .prepare(`UPDATE moderation_rules SET enabled = ? WHERE id = ? AND page_id = ?`)
    .run(enabled ? 1 : 0, ruleId, pageId);
}

export function deleteRule(pageId: string, ruleId: number): void {
  db()
    .prepare(`DELETE FROM moderation_rules WHERE id = ? AND page_id = ?`)
    .run(ruleId, pageId);
}

export interface LogEntry {
  id: number;
  commentId: string;
  postId: string | null;
  ruleId: number | null;
  ruleName: string | null;
  action: string;
  authorName: string | null;
  message: string | null;
  status: string;
  detail: string | null;
  createdAt: number;
}

/**
 * Returns false when this comment was already handled by this rule.
 *
 * The unique index on (comment_id, rule_id) is what makes the moderation run
 * idempotent: re-running over the same comments will not re-hide, re-delete,
 * or — most importantly — post a duplicate auto-reply.
 */
export function claimAction(params: {
  pageId: string;
  commentId: string;
  ruleId: number;
}): boolean {
  const result = db()
    .prepare(
      `INSERT OR IGNORE INTO moderation_log
         (page_id, comment_id, post_id, rule_id, action, status, created_at)
       VALUES (@pageId, @commentId, NULL, @ruleId, 'pending', 'pending', @ts)`,
    )
    .run({
      pageId: params.pageId,
      commentId: params.commentId,
      ruleId: params.ruleId,
      ts: now(),
    });

  return result.changes > 0;
}

export function completeAction(params: {
  pageId: string;
  commentId: string;
  ruleId: number;
  ruleName: string | null;
  postId: string | null;
  action: string;
  authorName: string | null;
  message: string | null;
  status: "applied" | "failed" | "skipped";
  detail?: string | null;
}): void {
  db()
    .prepare(
      `UPDATE moderation_log
          SET post_id = @postId,
              rule_name = @ruleName,
              action = @action,
              author_name = @authorName,
              message = @message,
              status = @status,
              detail = @detail
        WHERE comment_id = @commentId
          AND rule_id IS @ruleId
          AND page_id = @pageId`,
    )
    .run({
      pageId: params.pageId,
      commentId: params.commentId,
      ruleId: params.ruleId,
      ruleName: params.ruleName,
      postId: params.postId,
      action: params.action,
      authorName: params.authorName,
      message: params.message,
      status: params.status,
      detail: params.detail ?? null,
    });
}

/**
 * Manual actions taken from the inbox are always appended, never deduped —
 * each one is a separate entry in the audit trail. (SQLite treats NULLs in a
 * unique index as distinct, so the rule dedup index does not apply to these
 * rule_id IS NULL rows.)
 */
export function logManualAction(params: {
  pageId: string;
  commentId: string;
  postId: string | null;
  action: string;
  authorName: string | null;
  message: string | null;
  status: "applied" | "failed";
  detail?: string | null;
}): void {
  db()
    .prepare(
      `INSERT INTO moderation_log
         (page_id, comment_id, post_id, rule_id, rule_name, action,
          author_name, message, status, detail, created_at)
       VALUES (@pageId, @commentId, @postId, NULL, 'manual', @action,
               @authorName, @message, @status, @detail, @ts)`,
    )
    .run({
      pageId: params.pageId,
      commentId: params.commentId,
      postId: params.postId,
      action: params.action,
      authorName: params.authorName,
      message: params.message,
      status: params.status,
      detail: params.detail ?? null,
      ts: now(),
    });
}

export function listLog(pageId: string, limit = 100): LogEntry[] {
  const rows = db()
    .prepare(
      `SELECT id, comment_id, post_id, rule_id, rule_name, action, author_name,
              message, status, detail, created_at
         FROM moderation_log
        WHERE page_id = ? AND status != 'pending'
        ORDER BY created_at DESC, id DESC
        LIMIT ?`,
    )
    .all(pageId, limit) as Array<Record<string, never>>;

  return rows.map((row: any) => ({
    id: row.id,
    commentId: row.comment_id,
    postId: row.post_id,
    ruleId: row.rule_id,
    ruleName: row.rule_name,
    action: row.action,
    authorName: row.author_name,
    message: row.message,
    status: row.status,
    detail: row.detail,
    createdAt: row.created_at,
  }));
}
