import { cookies } from "next/headers";
import { sign, safeEqual } from "./crypto";

/**
 * Session is just a signed cookie holding the Facebook user id. Tokens stay in
 * SQLite — nothing sensitive is handed to the browser.
 */

const COOKIE = "ps_session";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 days

export async function setSession(accountId: string): Promise<void> {
  const store = await cookies();
  store.set(COOKIE, `${accountId}.${sign(accountId)}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE,
  });
}

export async function getSession(): Promise<string | null> {
  const store = await cookies();
  const raw = store.get(COOKIE)?.value;
  if (!raw) return null;

  const separator = raw.lastIndexOf(".");
  if (separator < 1) return null;

  const accountId = raw.slice(0, separator);
  const signature = raw.slice(separator + 1);
  if (!safeEqual(signature, sign(accountId))) return null;

  return accountId;
}

export async function clearSession(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE);
}
