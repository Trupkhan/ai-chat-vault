/**
 * Monetization readiness rules.
 *
 * IMPORTANT — read before trusting the output:
 *
 * Meta does not expose a general "am I eligible?" API. The Monetization
 * Eligibility API exists but is limited to approved partners, so this module
 * does the next best thing: it encodes Meta's *published* thresholds and checks
 * them against the numbers the Graph API does give us.
 *
 * That means two honest limitations, surfaced in the UI rather than hidden:
 *  1. Thresholds change. They are dated below and must be re-checked against
 *     Meta's monetization docs — this file is a snapshot, not a live feed.
 *  2. Policy compliance (content standards, partner policies, country, age)
 *     cannot be measured from the API at all. Those are self-reported, and a
 *     "ready" score here is not a decision by Meta.
 *
 * Source: Meta Business Help Centre monetization eligibility standards.
 * Snapshot date: 2026-08. Verify before relying on any threshold.
 */

export const THRESHOLDS_REVIEWED = "2026-08";

export const PRODUCTS = ["in_stream_ads", "stars", "subscriptions"] as const;
export type Product = (typeof PRODUCTS)[number];

export const PRODUCT_LABELS: Record<Product, string> = {
  in_stream_ads: "In-stream ads",
  stars: "Stars",
  subscriptions: "Subscriptions",
};

/** Numbers we can read from the Graph API. `null` means "could not measure". */
export interface Signals {
  followers: number | null;
  isPublished: boolean | null;
  videoCount: number | null;
  postsLast30Days: number | null;
  watchMinutes60Days: number | null;
  engagements60Days: number | null;
}

export type CheckStatus = "pass" | "fail" | "unknown" | "manual";

export interface CheckDefinition {
  id: string;
  /** `null` = applies to every product (baseline requirement). */
  product: Product | null;
  label: string;
  detail: string;
  /** Auto checks read Signals; manual checks are answered by the operator. */
  kind: "auto" | "manual";
  evaluate?: (signals: Signals) => { status: CheckStatus; actual?: string };
}

function numeric(
  value: number | null,
  threshold: number,
  format: (value: number) => string,
): { status: CheckStatus; actual?: string } {
  if (value === null) return { status: "unknown" };
  return {
    status: value >= threshold ? "pass" : "fail",
    actual: format(value),
  };
}

export const CHECKS: CheckDefinition[] = [
  // --- Baseline, applies to every product ---------------------------------
  {
    id: "page_published",
    product: null,
    label: "Page is published and visible",
    detail: "An unpublished page cannot be monetized.",
    kind: "auto",
    evaluate: (signals) => {
      if (signals.isPublished === null) return { status: "unknown" };
      return {
        status: signals.isPublished ? "pass" : "fail",
        actual: signals.isPublished ? "Published" : "Unpublished",
      };
    },
  },
  {
    id: "recent_activity",
    product: null,
    label: "Posted in the last 30 days",
    detail: "Dormant pages are not considered active for monetization.",
    kind: "auto",
    evaluate: (signals) => {
      if (signals.postsLast30Days === null) return { status: "unknown" };
      return {
        status: signals.postsLast30Days > 0 ? "pass" : "fail",
        actual: `${signals.postsLast30Days} posts`,
      };
    },
  },
  {
    id: "partner_policies",
    product: null,
    label: "Complies with Partner Monetisation Policies",
    detail:
      "Covers page authenticity, account history and community standards. Not measurable from the API.",
    kind: "manual",
  },
  {
    id: "content_policies",
    product: null,
    label: "Complies with Content Monetisation Policies",
    detail:
      "Original content, no reused or repurposed material, no restricted content categories.",
    kind: "manual",
  },
  {
    id: "eligible_country",
    product: null,
    label: "Page and admin are in an eligible country",
    detail:
      "Availability differs per product and changes over time. Check Meta's current country list.",
    kind: "manual",
  },
  {
    id: "admin_age",
    product: null,
    label: "Page admin is 18 or older",
    detail: "Required for any payout-bearing product.",
    kind: "manual",
  },

  // --- In-stream ads -------------------------------------------------------
  {
    id: "ads_followers",
    product: "in_stream_ads",
    label: "10,000 followers",
    detail: "Meta's published follower threshold for in-stream ads.",
    kind: "auto",
    evaluate: (signals) =>
      numeric(signals.followers, 10_000, (value) => `${value.toLocaleString()} followers`),
  },
  {
    id: "ads_watch_minutes",
    product: "in_stream_ads",
    label: "600,000 watch minutes in the last 60 days",
    detail:
      "Across all video content. Read from the page_video_view_time metric where your Graph version exposes it.",
    kind: "auto",
    evaluate: (signals) =>
      numeric(signals.watchMinutes60Days, 600_000, (value) =>
        `${Math.round(value).toLocaleString()} minutes`,
      ),
  },
  {
    id: "ads_active_videos",
    product: "in_stream_ads",
    label: "At least 5 active video uploads",
    detail: "Counted from the page's video library.",
    kind: "auto",
    evaluate: (signals) =>
      numeric(signals.videoCount, 5, (value) => `${value} videos`),
  },

  // --- Stars ---------------------------------------------------------------
  {
    id: "stars_followers",
    product: "stars",
    label: "500 followers",
    detail: "Meta's published follower threshold for Stars.",
    kind: "auto",
    evaluate: (signals) =>
      numeric(signals.followers, 500, (value) => `${value.toLocaleString()} followers`),
  },
  {
    id: "stars_duration",
    product: "stars",
    label: "Held that follower count for 30 consecutive days",
    detail:
      "The Graph API exposes today's follower count, not the 30-day history, so confirm this yourself.",
    kind: "manual",
  },

  // --- Subscriptions -------------------------------------------------------
  {
    id: "subs_followers",
    product: "subscriptions",
    label: "10,000 followers (or 250+ return viewers)",
    detail:
      "Either threshold qualifies. Return viewers are not exposed by the API — if you meet that instead, mark this manually.",
    kind: "auto",
    evaluate: (signals) =>
      numeric(signals.followers, 10_000, (value) => `${value.toLocaleString()} followers`),
  },
  {
    id: "subs_engagement",
    product: "subscriptions",
    label: "50,000 post engagements in the last 60 days",
    detail:
      "The alternative threshold is 180,000 watch minutes; meeting either one qualifies.",
    kind: "auto",
    evaluate: (signals) => {
      if (signals.engagements60Days === null && signals.watchMinutes60Days === null) {
        return { status: "unknown" };
      }
      const engagements = signals.engagements60Days ?? 0;
      const minutes = signals.watchMinutes60Days ?? 0;
      const qualifies = engagements >= 50_000 || minutes >= 180_000;
      return {
        status: qualifies ? "pass" : "fail",
        actual: `${engagements.toLocaleString()} engagements, ${Math.round(
          minutes,
        ).toLocaleString()} watch minutes`,
      };
    },
  },
];

export interface EvaluatedCheck extends CheckDefinition {
  status: CheckStatus;
  actual?: string;
}

export interface ProductReport {
  product: Product;
  label: string;
  checks: EvaluatedCheck[];
  passed: number;
  total: number;
  blocking: EvaluatedCheck[];
  ready: boolean;
}

export function evaluate(
  signals: Signals,
  manualAnswers: Record<string, boolean>,
): { baseline: EvaluatedCheck[]; products: ProductReport[] } {
  const evaluateOne = (check: CheckDefinition): EvaluatedCheck => {
    if (check.kind === "manual") {
      const answered = manualAnswers[check.id];
      return { ...check, status: answered ? "pass" : "manual" };
    }
    const result = check.evaluate?.(signals) ?? { status: "unknown" as CheckStatus };
    return { ...check, status: result.status, actual: result.actual };
  };

  const baseline = CHECKS.filter((check) => check.product === null).map(evaluateOne);

  const products = PRODUCTS.map((product) => {
    const own = CHECKS.filter((check) => check.product === product).map(evaluateOne);
    const all = [...baseline, ...own];
    const passed = all.filter((check) => check.status === "pass").length;
    const blocking = all.filter((check) => check.status === "fail");

    return {
      product,
      label: PRODUCT_LABELS[product],
      checks: own,
      passed,
      total: all.length,
      blocking,
      // "Ready" means nothing is failing and nothing is unconfirmed — an
      // unanswered manual check is not a pass.
      ready: all.every((check) => check.status === "pass"),
    };
  });

  return { baseline, products };
}
