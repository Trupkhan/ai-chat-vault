"use client";

/** Error carrying the structured payload our route handlers return. */
export class ApiClientError extends Error {
  constructor(
    message: string,
    readonly hint?: string,
    readonly needsReauth?: boolean,
    readonly status?: number,
  ) {
    super(message);
    this.name = "ApiClientError";
  }
}

export async function apiGet<T>(path: string): Promise<T> {
  return request<T>(path, { method: "GET" });
}

export async function apiSend<T>(
  path: string,
  body: unknown,
  method: "POST" | "DELETE" | "PATCH" = "POST",
): Promise<T> {
  return request<T>(path, {
    method,
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function request<T>(path: string, init: RequestInit): Promise<T> {
  const response = await fetch(path, { ...init, cache: "no-store" });
  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};

  if (!response.ok) {
    throw new ApiClientError(
      payload.error || `Request failed (${response.status})`,
      payload.hint,
      payload.needsReauth,
      response.status,
    );
  }
  return payload as T;
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";
  return new Intl.NumberFormat(undefined, { notation: value >= 10000 ? "compact" : "standard" })
    .format(value);
}

export function formatDate(value: string | number | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "number" ? new Date(value * 1000) : new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}
