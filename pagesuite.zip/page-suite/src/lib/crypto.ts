import crypto from "node:crypto";
import { env } from "./env";

/**
 * Page access tokens are long-lived credentials that can post as the page, so
 * they are encrypted at rest with AES-256-GCM. Losing TOKEN_ENCRYPTION_KEY
 * means every stored token becomes unreadable and the user has to reconnect —
 * which is the correct failure mode.
 */

const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 12;

function key(): Buffer {
  const raw = Buffer.from(env.tokenEncryptionKey, "hex");
  if (raw.length !== 32) {
    throw new Error(
      "TOKEN_ENCRYPTION_KEY must be 32 bytes hex-encoded (64 hex characters).",
    );
  }
  return raw;
}

export function encrypt(plaintext: string): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key(), iv);
  const encrypted = Buffer.concat([
    cipher.update(plaintext, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return [
    iv.toString("base64"),
    tag.toString("base64"),
    encrypted.toString("base64"),
  ].join(".");
}

export function decrypt(payload: string): string {
  const [ivPart, tagPart, dataPart] = payload.split(".");
  if (!ivPart || !tagPart || !dataPart) {
    throw new Error("Stored token is malformed and cannot be decrypted.");
  }
  const decipher = crypto.createDecipheriv(
    ALGORITHM,
    key(),
    Buffer.from(ivPart, "base64"),
  );
  decipher.setAuthTag(Buffer.from(tagPart, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(dataPart, "base64")),
    decipher.final(),
  ]).toString("utf8");
}

/** Constant-time comparison for cookie signatures and the cron secret. */
export function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function sign(value: string): string {
  return crypto
    .createHmac("sha256", env.sessionSecret)
    .update(value)
    .digest("base64url");
}

/**
 * Meta requires appsecret_proof on server-side calls when the app has the
 * setting enabled, and it is harmless when it doesn't — so we always send it.
 */
export function appSecretProof(accessToken: string): string {
  return crypto
    .createHmac("sha256", env.appSecret)
    .update(accessToken)
    .digest("hex");
}
