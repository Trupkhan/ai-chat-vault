import { env } from "./env";
import { appSecretProof } from "./crypto";

/**
 * Thin Graph API client.
 *
 * Two rules it enforces everywhere:
 *  1. Graph errors are surfaced, never swallowed. A silently-empty chart is
 *     worse than an error message that names the missing permission.
 *  2. Rate limiting and transient 5xx are retried with backoff; 4xx is not,
 *     because retrying a rejected request just burns quota.
 */

export class GraphError extends Error {
  readonly status: number;
  readonly code?: number;
  readonly subcode?: number;
  readonly type?: string;
  readonly fbTraceId?: string;

  constructor(
    status: number,
    body: { message?: string; code?: number; error_subcode?: number; type?: string; fbtrace_id?: string },
  ) {
    super(body.message || `Graph API request failed with status ${status}`);
    this.name = "GraphError";
    this.status = status;
    this.code = body.code;
    this.subcode = body.error_subcode;
    this.type = body.type;
    this.fbTraceId = body.fbtrace_id;
  }

  /**
   * Meta signals "token is dead, make the user reconnect" with code 190, and
   * "you're missing a permission" with 200/10/3. Those need different UI, so
   * callers can branch on this.
   */
  get needsReauth(): boolean {
    return this.code === 190 || this.code === 102;
  }

  get isPermissionError(): boolean {
    return this.code === 200 || this.code === 10 || this.code === 3;
  }

  /** Application request limit / user request limit reached. */
  get isRateLimit(): boolean {
    return this.code === 4 || this.code === 17 || this.code === 32 || this.code === 613;
  }
}

type GraphParams = Record<string, string | number | boolean | undefined>;

interface GraphRequestOptions {
  method?: "GET" | "POST" | "DELETE";
  params?: GraphParams;
  body?: GraphParams;
  accessToken: string;
  /** Retries for rate limits and 5xx. */
  retries?: number;
}

const BASE = "https://graph.facebook.com";

function buildUrl(pathname: string, params: GraphParams, accessToken: string): string {
  const clean = pathname.startsWith("/") ? pathname.slice(1) : pathname;
  const url = new URL(`${BASE}/${env.graphVersion}/${clean}`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined) url.searchParams.set(key, String(value));
  }
  url.searchParams.set("access_token", accessToken);
  url.searchParams.set("appsecret_proof", appSecretProof(accessToken));
  return url.toString();
}

export async function graph<T>(
  pathname: string,
  options: GraphRequestOptions,
): Promise<T> {
  const { method = "GET", params = {}, body, accessToken, retries = 2 } = options;

  let attempt = 0;
  // Retry loop: only rate limits and 5xx come back around.
  for (;;) {
    const url = buildUrl(pathname, method === "GET" ? params : params, accessToken);

    const init: RequestInit = { method, cache: "no-store" };
    if (body) {
      const form = new URLSearchParams();
      for (const [key, value] of Object.entries(body)) {
        if (value !== undefined) form.set(key, String(value));
      }
      init.body = form;
      init.headers = { "content-type": "application/x-www-form-urlencoded" };
    }

    let response: Response;
    try {
      response = await fetch(url, init);
    } catch (cause) {
      if (attempt >= retries) {
        throw new GraphError(0, {
          message: `Network error calling Graph API: ${(cause as Error).message}`,
        });
      }
      await sleep(backoffMs(attempt++));
      continue;
    }

    const text = await response.text();
    const payload = text ? safeJson(text) : {};

    if (response.ok) return payload as T;

    const error = new GraphError(response.status, payload?.error ?? { message: text });

    const retryable = error.isRateLimit || response.status >= 500;
    if (retryable && attempt < retries) {
      await sleep(backoffMs(attempt++));
      continue;
    }
    throw error;
  }
}

function safeJson(text: string): any {
  try {
    return JSON.parse(text);
  } catch {
    return { error: { message: text.slice(0, 500) } };
  }
}

function backoffMs(attempt: number): number {
  // 1s, 2s, 4s ... with jitter so parallel calls don't retry in lockstep.
  return 2 ** attempt * 1000 + Math.random() * 250;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Walks `paging.next` up to `maxPages`. Graph cursors can run very long on
 * busy pages, so every caller sets an explicit ceiling rather than looping
 * until the data happens to end.
 */
export async function graphPaged<T>(
  pathname: string,
  options: GraphRequestOptions & { maxPages?: number },
): Promise<T[]> {
  const { maxPages = 5 } = options;
  const collected: T[] = [];

  let page = await graph<{ data: T[]; paging?: { next?: string } }>(pathname, options);
  collected.push(...(page.data ?? []));

  let pageCount = 1;
  while (page.paging?.next && pageCount < maxPages) {
    const response = await fetch(page.paging.next, { cache: "no-store" });
    const text = await response.text();
    const payload = safeJson(text);
    if (!response.ok) throw new GraphError(response.status, payload?.error ?? {});
    page = payload;
    collected.push(...(page.data ?? []));
    pageCount++;
  }

  return collected;
}

/** OAuth code -> short-lived user token. */
export async function exchangeCodeForToken(code: string): Promise<{
  access_token: string;
  expires_in?: number;
}> {
  const url = new URL(`${BASE}/${env.graphVersion}/oauth/access_token`);
  url.searchParams.set("client_id", env.appId);
  url.searchParams.set("client_secret", env.appSecret);
  url.searchParams.set("redirect_uri", env.redirectUri);
  url.searchParams.set("code", code);

  const response = await fetch(url.toString(), { cache: "no-store" });
  const payload = safeJson(await response.text());
  if (!response.ok) throw new GraphError(response.status, payload?.error ?? {});
  return payload;
}

/** Short-lived user token -> ~60 day token. Page tokens derived from a
 *  long-lived user token do not expire, which is what we want for the
 *  scheduler and the moderation poller. */
export async function exchangeForLongLivedToken(shortToken: string): Promise<{
  access_token: string;
  expires_in?: number;
}> {
  const url = new URL(`${BASE}/${env.graphVersion}/oauth/access_token`);
  url.searchParams.set("grant_type", "fb_exchange_token");
  url.searchParams.set("client_id", env.appId);
  url.searchParams.set("client_secret", env.appSecret);
  url.searchParams.set("fb_exchange_token", shortToken);

  const response = await fetch(url.toString(), { cache: "no-store" });
  const payload = safeJson(await response.text());
  if (!response.ok) throw new GraphError(response.status, payload?.error ?? {});
  return payload;
}
