import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { env } from "./env";

/**
 * SQLite is deliberate here: this is a single-operator tool, the data is small,
 * and a file on disk means no database to provision before the app runs.
 * If this ever becomes multi-tenant, the schema below ports to Postgres as-is.
 */

let instance: Database.Database | null = null;

export function db(): Database.Database {
  if (instance) return instance;

  const file = path.resolve(process.cwd(), env.databasePath);
  fs.mkdirSync(path.dirname(file), { recursive: true });

  instance = new Database(file);
  instance.pragma("journal_mode = WAL");
  instance.pragma("foreign_keys = ON");
  migrate(instance);
  return instance;
}

function migrate(database: Database.Database): void {
  database.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      id                  TEXT PRIMARY KEY,       -- Facebook user id
      name                TEXT NOT NULL,
      user_token_enc      TEXT NOT NULL,          -- long-lived user token
      token_expires_at    INTEGER,                -- unix seconds, null = no expiry
      created_at          INTEGER NOT NULL,
      updated_at          INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pages (
      id                  TEXT PRIMARY KEY,       -- Facebook page id
      account_id          TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      name                TEXT NOT NULL,
      category            TEXT,
      page_token_enc      TEXT NOT NULL,
      tasks               TEXT,                   -- JSON array of granted tasks
      created_at          INTEGER NOT NULL,
      updated_at          INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS moderation_rules (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      page_id             TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
      name                TEXT NOT NULL,
      enabled             INTEGER NOT NULL DEFAULT 1,
      match_type          TEXT NOT NULL,          -- 'keyword' | 'regex' | 'link'
      pattern             TEXT NOT NULL,
      action              TEXT NOT NULL,          -- 'flag' | 'hide' | 'delete' | 'reply'
      reply_text          TEXT,
      priority            INTEGER NOT NULL DEFAULT 100,
      created_at          INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_rules_page ON moderation_rules(page_id, enabled);

    CREATE TABLE IF NOT EXISTS moderation_log (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      page_id             TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
      comment_id          TEXT NOT NULL,
      post_id             TEXT,
      rule_id             INTEGER,
      rule_name           TEXT,
      action              TEXT NOT NULL,
      author_name         TEXT,
      message             TEXT,
      status              TEXT NOT NULL,          -- 'applied' | 'failed' | 'skipped'
      detail              TEXT,
      created_at          INTEGER NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_log_comment_rule
      ON moderation_log(comment_id, rule_id);

    CREATE INDEX IF NOT EXISTS idx_log_page_time
      ON moderation_log(page_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS monetization_answers (
      page_id             TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
      check_id            TEXT NOT NULL,
      answer              INTEGER NOT NULL,       -- 0 = no, 1 = yes
      updated_at          INTEGER NOT NULL,
      PRIMARY KEY (page_id, check_id)
    );
  `);
}

export function now(): number {
  return Math.floor(Date.now() / 1000);
}
