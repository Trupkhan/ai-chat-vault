/**
 * Client-safe metric constants.
 *
 * Kept separate from lib/insights.ts because that module pulls in the Graph
 * client, which reads app secrets — importing it from a client component would
 * drag server-only code into the browser bundle.
 */

/** Page-level daily metrics we chart. Order affects display order only. */
export const PAGE_METRICS = [
  "page_impressions",
  "page_impressions_unique",
  "page_post_engagements",
  "page_fan_adds",
  "page_fan_removes",
  "page_views_total",
] as const;

export const METRIC_LABELS: Record<string, string> = {
  page_impressions: "Impressions",
  page_impressions_unique: "Reach (unique)",
  page_post_engagements: "Post engagements",
  page_fan_adds: "New followers",
  page_fan_removes: "Unfollows",
  page_views_total: "Page views",
};
