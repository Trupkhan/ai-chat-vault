import { graphPaged } from "./graph";

export interface PageComment {
  id: string;
  postId: string;
  postMessage: string;
  message: string;
  authorName: string | null;
  createdTime: string;
  likeCount: number;
  isHidden: boolean;
  permalink: string | null;
}

interface RawFeed {
  id: string;
  message?: string;
  story?: string;
  permalink_url?: string;
  comments?: {
    data: Array<{
      id: string;
      message?: string;
      created_time: string;
      like_count?: number;
      is_hidden?: boolean;
      permalink_url?: string;
      from?: { id: string; name?: string };
    }>;
  };
}

/**
 * Pulls comments from the page's most recent posts.
 *
 * Comments are fetched nested inside the post query rather than one request
 * per post — a single call covers the whole window, which matters because the
 * moderation run is on a timer and the Graph rate limit is per-app.
 *
 * `from` is only populated for commenters the page is allowed to see; for
 * everyone else it comes back missing and we record the author as unknown
 * rather than inventing one.
 */
export async function fetchRecentComments(params: {
  pageId: string;
  token: string;
  postLimit?: number;
  commentsPerPost?: number;
}): Promise<PageComment[]> {
  const { pageId, token, postLimit = 10, commentsPerPost = 50 } = params;

  const posts = await graphPaged<RawFeed>(`${pageId}/posts`, {
    params: {
      limit: postLimit,
      fields: `id,message,story,permalink_url,comments.limit(${commentsPerPost}).order(reverse_chronological){id,message,created_time,like_count,is_hidden,permalink_url,from}`,
    },
    accessToken: token,
    maxPages: 1,
  });

  const comments: PageComment[] = [];

  for (const post of posts) {
    for (const comment of post.comments?.data ?? []) {
      comments.push({
        id: comment.id,
        postId: post.id,
        postMessage: post.message ?? post.story ?? "",
        message: comment.message ?? "",
        authorName: comment.from?.name ?? null,
        createdTime: comment.created_time,
        likeCount: comment.like_count ?? 0,
        isHidden: comment.is_hidden ?? false,
        permalink: comment.permalink_url ?? null,
      });
    }
  }

  return comments.sort(
    (a, b) => new Date(b.createdTime).getTime() - new Date(a.createdTime).getTime(),
  );
}
