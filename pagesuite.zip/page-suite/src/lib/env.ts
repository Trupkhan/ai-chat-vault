/**
 * Environment access with explicit failure.
 *
 * Every value here is required for the app to do anything useful, so we fail
 * loudly at the point of use rather than letting `undefined` reach the Graph
 * API and come back as a confusing OAuth error.
 */

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `Missing environment variable ${name}. Copy .env.example to .env.local and fill it in.`,
    );
  }
  return value;
}

export const env = {
  get appId() {
    return required("FB_APP_ID");
  },
  get appSecret() {
    return required("FB_APP_SECRET");
  },
  get redirectUri() {
    return required("FB_REDIRECT_URI");
  },
  get graphVersion() {
    return process.env.FB_GRAPH_VERSION || "v23.0";
  },
  get tokenEncryptionKey() {
    return required("TOKEN_ENCRYPTION_KEY");
  },
  get sessionSecret() {
    return required("SESSION_SECRET");
  },
  get databasePath() {
    return process.env.DATABASE_PATH || "./data/page-suite.db";
  },
  get cronSecret() {
    return process.env.CRON_SECRET || "";
  },
};

/**
 * Permissions requested at login.
 *
 * Everything here is read or page-management scoped. There is deliberately no
 * payout, billing, or ads-spend permission: this app reports and publishes, it
 * never touches money.
 */
export const FB_SCOPES = [
  "pages_show_list", // enumerate the pages the user administers
  "pages_read_engagement", // page + post metadata
  "pages_read_user_content", // comments written by other people
  "pages_manage_posts", // create and schedule posts
  "pages_manage_engagement", // hide / delete / reply to comments
  "read_insights", // page and post insight metrics
].join(",");
