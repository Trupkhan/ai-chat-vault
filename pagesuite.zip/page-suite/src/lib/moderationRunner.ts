import { graph } from "./graph";
import { fetchRecentComments, type PageComment } from "./commentSource";
import { firstMatch, type Rule, type Action } from "./moderation";
import { listRules, claimAction, completeAction } from "./moderationStore";

export interface RunOutcome {
  commentId: string;
  ruleName: string;
  action: Action;
  status: "applied" | "failed" | "skipped" | "would-apply";
  detail?: string;
  message: string;
  authorName: string | null;
}

export interface RunSummary {
  scanned: number;
  matched: number;
  applied: number;
  failed: number;
  skipped: number;
  dryRun: boolean;
  outcomes: RunOutcome[];
}

/** Performs the Graph-side effect for a matched rule. */
async function applyAction(
  comment: PageComment,
  rule: Rule,
  token: string,
): Promise<void> {
  switch (rule.action) {
    case "hide":
      await graph(comment.id, {
        method: "POST",
        accessToken: token,
        body: { is_hidden: true },
      });
      return;
    case "delete":
      await graph(comment.id, { method: "DELETE", accessToken: token });
      return;
    case "reply":
      await graph(`${comment.id}/comments`, {
        method: "POST",
        accessToken: token,
        body: { message: rule.replyText ?? "" },
      });
      return;
    case "flag":
      // Recorded in the log only — deliberately no side effect.
      return;
  }
}

/**
 * Scans recent comments and applies the first matching rule to each.
 *
 * Idempotency is enforced by `claimAction`: a (comment, rule) pair is written
 * to the log *before* the Graph call, so a repeated run — or two overlapping
 * runs — cannot double-hide a comment or post the same auto-reply twice.
 *
 * `dryRun` reports what would happen and touches nothing, which is the only
 * safe way to try out a new delete rule.
 */
export async function runModeration(params: {
  pageId: string;
  token: string;
  dryRun?: boolean;
  postLimit?: number;
}): Promise<RunSummary> {
  const { pageId, token, dryRun = false, postLimit = 10 } = params;

  const rules = listRules(pageId).filter((rule) => rule.enabled);
  const comments = await fetchRecentComments({ pageId, token, postLimit });

  const summary: RunSummary = {
    scanned: comments.length,
    matched: 0,
    applied: 0,
    failed: 0,
    skipped: 0,
    dryRun,
    outcomes: [],
  };

  if (rules.length === 0) return summary;

  for (const comment of comments) {
    // Already-hidden comments are left alone; re-hiding is a no-op and
    // deleting one the operator chose to hide would be a surprise.
    if (comment.isHidden) continue;

    const rule = firstMatch(rules, comment.message);
    if (!rule) continue;

    summary.matched += 1;

    if (dryRun) {
      summary.outcomes.push({
        commentId: comment.id,
        ruleName: rule.name,
        action: rule.action,
        status: "would-apply",
        message: comment.message,
        authorName: comment.authorName,
      });
      continue;
    }

    const claimed = claimAction({ pageId, commentId: comment.id, ruleId: rule.id });
    if (!claimed) {
      summary.skipped += 1;
      continue;
    }

    try {
      await applyAction(comment, rule, token);
      completeAction({
        pageId,
        commentId: comment.id,
        ruleId: rule.id,
        ruleName: rule.name,
        postId: comment.postId,
        action: rule.action,
        authorName: comment.authorName,
        message: comment.message,
        status: "applied",
      });
      summary.applied += 1;
      summary.outcomes.push({
        commentId: comment.id,
        ruleName: rule.name,
        action: rule.action,
        status: "applied",
        message: comment.message,
        authorName: comment.authorName,
      });
    } catch (cause) {
      const detail = cause instanceof Error ? cause.message : "Unknown error";
      completeAction({
        pageId,
        commentId: comment.id,
        ruleId: rule.id,
        ruleName: rule.name,
        postId: comment.postId,
        action: rule.action,
        authorName: comment.authorName,
        message: comment.message,
        status: "failed",
        detail,
      });
      summary.failed += 1;
      summary.outcomes.push({
        commentId: comment.id,
        ruleName: rule.name,
        action: rule.action,
        status: "failed",
        detail,
        message: comment.message,
        authorName: comment.authorName,
      });
    }
  }

  return summary;
}
