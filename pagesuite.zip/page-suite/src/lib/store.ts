import { db, now } from "./db";
import { encrypt, decrypt } from "./crypto";

export interface PageRecord {
  id: string;
  accountId: string;
  name: string;
  category: string | null;
  tasks: string[];
}

interface PageRow {
  id: string;
  account_id: string;
  name: string;
  category: string | null;
  page_token_enc: string;
  tasks: string | null;
}

export function saveAccount(params: {
  id: string;
  name: string;
  userToken: string;
  expiresAt: number | null;
}): void {
  const timestamp = now();
  db()
    .prepare(
      `INSERT INTO accounts (id, name, user_token_enc, token_expires_at, created_at, updated_at)
       VALUES (@id, @name, @token, @expires, @ts, @ts)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         user_token_enc = excluded.user_token_enc,
         token_expires_at = excluded.token_expires_at,
         updated_at = excluded.updated_at`,
    )
    .run({
      id: params.id,
      name: params.name,
      token: encrypt(params.userToken),
      expires: params.expiresAt,
      ts: timestamp,
    });
}

export function savePages(
  accountId: string,
  pages: Array<{
    id: string;
    name: string;
    category?: string;
    access_token: string;
    tasks?: string[];
  }>,
): void {
  const timestamp = now();
  const statement = db().prepare(
    `INSERT INTO pages (id, account_id, name, category, page_token_enc, tasks, created_at, updated_at)
     VALUES (@id, @accountId, @name, @category, @token, @tasks, @ts, @ts)
     ON CONFLICT(id) DO UPDATE SET
       account_id = excluded.account_id,
       name = excluded.name,
       category = excluded.category,
       page_token_enc = excluded.page_token_enc,
       tasks = excluded.tasks,
       updated_at = excluded.updated_at`,
  );

  const insertAll = db().transaction(() => {
    for (const page of pages) {
      statement.run({
        id: page.id,
        accountId,
        name: page.name,
        category: page.category ?? null,
        token: encrypt(page.access_token),
        tasks: JSON.stringify(page.tasks ?? []),
        ts: timestamp,
      });
    }
  });
  insertAll();
}

function toRecord(row: PageRow): PageRecord {
  return {
    id: row.id,
    accountId: row.account_id,
    name: row.name,
    category: row.category,
    tasks: row.tasks ? (JSON.parse(row.tasks) as string[]) : [],
  };
}

export function listPages(accountId: string): PageRecord[] {
  const rows = db()
    .prepare(`SELECT * FROM pages WHERE account_id = ? ORDER BY name`)
    .all(accountId) as PageRow[];
  return rows.map(toRecord);
}

export function getPage(accountId: string, pageId: string): PageRecord | null {
  const row = db()
    .prepare(`SELECT * FROM pages WHERE id = ? AND account_id = ?`)
    .get(pageId, accountId) as PageRow | undefined;
  return row ? toRecord(row) : null;
}

/**
 * Returns the decrypted page token. Scoped by account id on purpose: the page
 * id alone must never be enough to pull a token out of storage.
 */
export function getPageToken(accountId: string, pageId: string): string | null {
  const row = db()
    .prepare(`SELECT page_token_enc FROM pages WHERE id = ? AND account_id = ?`)
    .get(pageId, accountId) as { page_token_enc: string } | undefined;
  return row ? decrypt(row.page_token_enc) : null;
}

/** Used by the cron-driven moderation run, which has no browser session. */
export function getPageTokenUnscoped(pageId: string): string | null {
  const row = db()
    .prepare(`SELECT page_token_enc FROM pages WHERE id = ?`)
    .get(pageId) as { page_token_enc: string } | undefined;
  return row ? decrypt(row.page_token_enc) : null;
}

export function listAllPages(): PageRecord[] {
  const rows = db().prepare(`SELECT * FROM pages ORDER BY name`).all() as PageRow[];
  return rows.map(toRecord);
}

export function getUserToken(accountId: string): string | null {
  const row = db()
    .prepare(`SELECT user_token_enc FROM accounts WHERE id = ?`)
    .get(accountId) as { user_token_enc: string } | undefined;
  return row ? decrypt(row.user_token_enc) : null;
}

export function deleteAccount(accountId: string): void {
  db().prepare(`DELETE FROM accounts WHERE id = ?`).run(accountId);
}
