/**
 * Comment moderation rule engine.
 *
 * Client-safe: no Graph or database imports, so the rule editor can reuse the
 * same validation the server enforces.
 */

export const MATCH_TYPES = ["keyword", "regex", "link"] as const;
export const ACTIONS = ["flag", "hide", "delete", "reply"] as const;

export type MatchType = (typeof MATCH_TYPES)[number];
export type Action = (typeof ACTIONS)[number];

export interface Rule {
  id: number;
  pageId: string;
  name: string;
  enabled: boolean;
  matchType: MatchType;
  pattern: string;
  action: Action;
  replyText: string | null;
  priority: number;
}

export const ACTION_LABELS: Record<Action, string> = {
  flag: "Flag only (no change)",
  hide: "Hide comment",
  delete: "Delete comment",
  reply: "Auto-reply",
};

export const MATCH_LABELS: Record<MatchType, string> = {
  keyword: "Contains any of these words (comma separated)",
  regex: "Matches this regular expression",
  link: "Contains a link (pattern is ignored)",
};

/**
 * A user-supplied regex runs against every incoming comment, so an
 * accidentally catastrophic pattern would stall the moderation run. We cap the
 * pattern length and the text we test, which bounds the damage without
 * pretending to be a full ReDoS analyser.
 */
export const MAX_PATTERN_LENGTH = 500;
const MAX_TEST_LENGTH = 5000;

const URL_PATTERN = /\b(?:https?:\/\/|www\.)\S+|\b[a-z0-9-]+\.(?:com|net|org|io|co|me|xyz|shop|link)\b/i;

export function validateRule(input: {
  name?: string;
  matchType?: string;
  pattern?: string;
  action?: string;
  replyText?: string | null;
}): { ok: boolean; error?: string } {
  if (!input.name?.trim()) return { ok: false, error: "Give the rule a name." };

  if (!MATCH_TYPES.includes(input.matchType as MatchType)) {
    return { ok: false, error: "Unknown match type." };
  }
  if (!ACTIONS.includes(input.action as Action)) {
    return { ok: false, error: "Unknown action." };
  }

  const matchType = input.matchType as MatchType;
  const pattern = input.pattern?.trim() ?? "";

  if (matchType !== "link") {
    if (!pattern) return { ok: false, error: "Add a pattern to match against." };
    if (pattern.length > MAX_PATTERN_LENGTH) {
      return { ok: false, error: `Pattern must be under ${MAX_PATTERN_LENGTH} characters.` };
    }
  }

  if (matchType === "regex") {
    try {
      new RegExp(pattern, "i");
    } catch (cause) {
      return { ok: false, error: `Invalid regular expression: ${(cause as Error).message}` };
    }
  }

  if (input.action === "reply" && !input.replyText?.trim()) {
    return { ok: false, error: "An auto-reply rule needs reply text." };
  }

  return { ok: true };
}

export function ruleMatches(rule: Rule, message: string): boolean {
  const text = (message ?? "").slice(0, MAX_TEST_LENGTH);
  if (!text.trim() && rule.matchType !== "link") return false;

  switch (rule.matchType) {
    case "keyword": {
      const words = rule.pattern
        .split(",")
        .map((word) => word.trim().toLowerCase())
        .filter(Boolean);
      const haystack = text.toLowerCase();
      return words.some((word) => haystack.includes(word));
    }
    case "regex": {
      try {
        return new RegExp(rule.pattern, "i").test(text);
      } catch {
        // A rule that no longer compiles should never match rather than throw
        // and abort the whole moderation run.
        return false;
      }
    }
    case "link":
      return URL_PATTERN.test(text);
    default:
      return false;
  }
}

/**
 * Lowest `priority` number wins. Only the first match applies, so a "delete
 * spam" rule ordered above "auto-reply to questions" can't double-fire.
 */
export function firstMatch(rules: Rule[], message: string): Rule | null {
  const ordered = [...rules]
    .filter((rule) => rule.enabled)
    .sort((a, b) => a.priority - b.priority || a.id - b.id);

  return ordered.find((rule) => ruleMatches(rule, message)) ?? null;
}
