import { graph, GraphError } from "./graph";

export { PAGE_METRICS, METRIC_LABELS } from "./metrics";

/**
 * Meta retires and renames page metrics fairly often, and Graph fails the
 * *entire* insights call if a single requested metric is unknown. Asking for
 * eight metrics and getting nothing back because one was deprecated is a bad
 * experience, so we degrade: try the batch, and on a "nonexisting field" style
 * error fall back to querying each metric on its own and reporting which ones
 * were unavailable.
 */

export interface MetricPoint {
  date: string; // YYYY-MM-DD
  value: number;
}

export interface MetricSeries {
  metric: string;
  points: MetricPoint[];
}

export interface InsightsResult {
  series: MetricSeries[];
  unavailable: Array<{ metric: string; reason: string }>;
}

interface RawInsight {
  name: string;
  period: string;
  values: Array<{ value: unknown; end_time?: string }>;
}

function toSeries(raw: RawInsight): MetricSeries {
  return {
    metric: raw.name,
    points: (raw.values ?? [])
      .filter((entry) => typeof entry.value === "number")
      .map((entry) => ({
        date: (entry.end_time ?? "").slice(0, 10),
        value: entry.value as number,
      }))
      .filter((point) => point.date.length === 10),
  };
}

export async function fetchPageInsights(params: {
  pageId: string;
  token: string;
  metrics: readonly string[];
  since: number;
  until: number;
}): Promise<InsightsResult> {
  const { pageId, token, metrics, since, until } = params;
  const query = { period: "day", since, until };

  try {
    const batch = await graph<{ data: RawInsight[] }>(`${pageId}/insights`, {
      params: { ...query, metric: metrics.join(",") },
      accessToken: token,
    });
    return { series: (batch.data ?? []).map(toSeries), unavailable: [] };
  } catch (error) {
    // Permission and auth problems are real failures — let them propagate so
    // the UI can tell the user to reconnect instead of silently showing zeros.
    if (
      error instanceof GraphError &&
      (error.needsReauth || error.isPermissionError || error.isRateLimit)
    ) {
      throw error;
    }
  }

  // Degraded path: one request per metric, keeping whatever works.
  const series: MetricSeries[] = [];
  const unavailable: Array<{ metric: string; reason: string }> = [];

  const results = await Promise.allSettled(
    metrics.map((metric) =>
      graph<{ data: RawInsight[] }>(`${pageId}/insights`, {
        params: { ...query, metric },
        accessToken: token,
      }),
    ),
  );

  results.forEach((result, index) => {
    const metric = metrics[index];
    if (result.status === "fulfilled") {
      const raw = result.value.data?.[0];
      if (raw) {
        series.push(toSeries(raw));
        return;
      }
      unavailable.push({ metric, reason: "No data returned for this period." });
    } else {
      const reason =
        result.reason instanceof Error ? result.reason.message : "Unavailable.";
      unavailable.push({ metric, reason });
    }
  });

  return { series, unavailable };
}

export function sumSeries(series: MetricSeries | undefined): number {
  if (!series) return 0;
  return series.points.reduce((total, point) => total + point.value, 0);
}

/**
 * Merges the per-metric series into one row per day, which is what a chart
 * with several lines needs.
 */
export function mergeByDate(
  series: MetricSeries[],
): Array<Record<string, string | number>> {
  const byDate = new Map<string, Record<string, string | number>>();

  for (const entry of series) {
    for (const point of entry.points) {
      const row = byDate.get(point.date) ?? { date: point.date };
      row[entry.metric] = point.value;
      byDate.set(point.date, row);
    }
  }

  return [...byDate.values()].sort((a, b) =>
    String(a.date).localeCompare(String(b.date)),
  );
}
