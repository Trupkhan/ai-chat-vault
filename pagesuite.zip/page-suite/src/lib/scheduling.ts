/**
 * Scheduling rules, kept in one place so the API route and the UI agree.
 *
 * Design note: we hand the schedule to Facebook via `scheduled_publish_time`
 * rather than running our own job queue. That means a queued post still goes
 * out if this app is offline, asleep, or redeployed — the only thing we own is
 * composing and cancelling.
 */

/** Meta requires a scheduled post to be at least 10 minutes out. */
export const MIN_LEAD_SECONDS = 10 * 60;

/** ...and at most 6 months out. 180 days is a safe read of "6 months". */
export const MAX_LEAD_SECONDS = 180 * 86400;

export interface ScheduleValidation {
  ok: boolean;
  error?: string;
}

export function validateScheduleTime(
  scheduledAt: number,
  nowSeconds = Math.floor(Date.now() / 1000),
): ScheduleValidation {
  if (!Number.isFinite(scheduledAt)) {
    return { ok: false, error: "Scheduled time is not a valid timestamp." };
  }

  const lead = scheduledAt - nowSeconds;

  if (lead < MIN_LEAD_SECONDS) {
    return {
      ok: false,
      error:
        "Facebook requires scheduled posts to be at least 10 minutes in the future.",
    };
  }

  if (lead > MAX_LEAD_SECONDS) {
    return {
      ok: false,
      error: "Facebook will not accept a post scheduled more than 6 months ahead.",
    };
  }

  return { ok: true };
}

export function validateContent(params: {
  message?: string;
  link?: string;
  photoUrl?: string;
}): ScheduleValidation {
  const hasMessage = Boolean(params.message?.trim());
  const hasLink = Boolean(params.link?.trim());
  const hasPhoto = Boolean(params.photoUrl?.trim());

  if (!hasMessage && !hasLink && !hasPhoto) {
    return { ok: false, error: "Add some text, a link, or an image URL." };
  }

  // A photo post carries its text as `caption`, so a bare image is fine, but a
  // link post with no text publishes as a naked URL — worth blocking.
  if (hasLink && !hasMessage && !hasPhoto) {
    return { ok: false, error: "Add text to go with the link." };
  }

  for (const [field, value] of Object.entries({
    link: params.link,
    photoUrl: params.photoUrl,
  })) {
    if (value?.trim() && !isHttpUrl(value.trim())) {
      return { ok: false, error: `The ${field} must be a valid http(s) URL.` };
    }
  }

  return { ok: true };
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}
