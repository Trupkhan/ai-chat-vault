import { NextResponse } from "next/server";
import { GraphError } from "./graph";
import { getSession } from "./session";
import { getPage, getPageToken, type PageRecord } from "./store";

/**
 * Shared plumbing for route handlers: resolve the session, resolve the page,
 * and turn thrown errors into responses the UI can render.
 */

export interface PageContext {
  accountId: string;
  page: PageRecord;
  token: string;
}

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
    readonly hint?: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export async function requirePage(request: Request): Promise<PageContext> {
  const accountId = await getSession();
  if (!accountId) {
    throw new ApiError(401, "Not signed in.", "Connect your Facebook account first.");
  }

  const pageId = new URL(request.url).searchParams.get("pageId");
  if (!pageId) {
    throw new ApiError(400, "Missing pageId query parameter.");
  }

  const page = getPage(accountId, pageId);
  const token = getPageToken(accountId, pageId);
  if (!page || !token) {
    throw new ApiError(404, "That page is not connected to this account.");
  }

  return { accountId, page, token };
}

export function handleError(error: unknown): NextResponse {
  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: error.message, hint: error.hint },
      { status: error.status },
    );
  }

  if (error instanceof GraphError) {
    // Map Meta's error taxonomy onto something actionable in the UI rather
    // than echoing "an unknown error occurred".
    let hint: string | undefined;
    if (error.needsReauth) {
      hint = "Your Facebook token expired or was revoked. Reconnect the account.";
    } else if (error.isPermissionError) {
      hint =
        "The app is missing a permission for this call. Re-connect and approve all requested permissions, or check the app's App Review status.";
    } else if (error.isRateLimit) {
      hint = "Graph API rate limit reached. Wait a few minutes and try again.";
    }

    return NextResponse.json(
      {
        error: error.message,
        code: error.code,
        subcode: error.subcode,
        traceId: error.fbTraceId,
        needsReauth: error.needsReauth,
        hint,
      },
      { status: error.status >= 400 && error.status < 600 ? error.status : 502 },
    );
  }

  const message = error instanceof Error ? error.message : "Unexpected error.";
  return NextResponse.json({ error: message }, { status: 500 });
}

export function ok<T>(data: T): NextResponse {
  return NextResponse.json(data);
}
